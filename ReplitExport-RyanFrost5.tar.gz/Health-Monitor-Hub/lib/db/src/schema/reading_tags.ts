import { pgTable, uuid, primaryKey } from "drizzle-orm/pg-core";
import { bpReadings } from "./bp_readings";
import { tags } from "./tags";

export const readingTags = pgTable(
  "reading_tags",
  {
    readingId: uuid("reading_id")
      .notNull()
      .references(() => bpReadings.id),
    tagId: uuid("tag_id")
      .notNull()
      .references(() => tags.id),
  },
  (table) => [primaryKey({ columns: [table.readingId, table.tagId] })]
);

export type ReadingTag = typeof readingTags.$inferSelect;
