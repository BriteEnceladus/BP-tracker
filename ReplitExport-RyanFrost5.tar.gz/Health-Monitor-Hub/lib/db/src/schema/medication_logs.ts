import { pgTable, uuid, timestamp } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { medications } from "./medications";
import { bpReadings } from "./bp_readings";

export const medicationLogs = pgTable("medication_logs", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  medicationId: uuid("medication_id")
    .notNull()
    .references(() => medications.id),
  takenAt: timestamp("taken_at", { withTimezone: true }).notNull(),
  readingId: uuid("reading_id").references(() => bpReadings.id),
});

export const insertMedicationLogSchema = createInsertSchema(medicationLogs).omit({ id: true });
export type InsertMedicationLog = z.infer<typeof insertMedicationLogSchema>;
export type MedicationLog = typeof medicationLogs.$inferSelect;
