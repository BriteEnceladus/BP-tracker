import {
  pgTable,
  uuid,
  varchar,
  integer,
  timestamp,
  text,
  index,
  check,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { users } from "./users";
import { devices } from "./devices";

export const bpReadings = pgTable(
  "bp_readings",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    userId: uuid("user_id").notNull().references(() => users.id),
    systolic: integer("systolic").notNull(),
    diastolic: integer("diastolic").notNull(),
    pulse: integer("pulse"),
    measuredAt: timestamp("measured_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().default(sql`now()`),
    arm: varchar("arm").notNull().default("unspecified"),
    position: varchar("position").notNull().default("sitting"),
    source: varchar("source").notNull().default("manual"),
    deviceId: uuid("device_id").references(() => devices.id),
    notes: text("notes"),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
    timezone: varchar("timezone").notNull(),
  },
  (table) => [
    index("bp_readings_user_id_measured_at_idx").on(table.userId, table.measuredAt),
    check("arm_check", sql`${table.arm} IN ('left', 'right', 'unspecified')`),
    check("position_check", sql`${table.position} IN ('sitting', 'standing', 'lying')`),
    check(
      "source_check",
      sql`${table.source} IN ('manual', 'bluetooth', 'apple_health', 'google_fit')`
    ),
  ]
);

export const insertBpReadingSchema = createInsertSchema(bpReadings).omit({
  id: true,
  createdAt: true,
  deletedAt: true,
});
export type InsertBpReading = z.infer<typeof insertBpReadingSchema>;
export type BpReading = typeof bpReadings.$inferSelect;
