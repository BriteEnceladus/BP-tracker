import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "./schema";
import {
  users,
  devices,
  bpReadings,
} from "./schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set before running the seed.");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool, { schema });

// ── Deterministic UUIDs so the seed is idempotent ──────────────────────────
const USER_ID = "00000000-0000-0000-0000-000000000001";
const DEVICE_1_ID = "00000000-0000-0000-0000-000000000010";
const DEVICE_2_ID = "00000000-0000-0000-0000-000000000011";

// Five readings spread over the past week, each in a different BP category:
//   Normal    : systolic < 120  AND diastolic < 80
//   Elevated  : systolic 120-129 AND diastolic < 80
//   Stage 1   : systolic 130-139 OR  diastolic 80-89
//   Stage 2   : systolic ≥ 140   OR  diastolic ≥ 90
//   Crisis    : systolic > 180   OR  diastolic > 120
const now = new Date();
const daysAgo = (n: number) => {
  const d = new Date(now);
  d.setUTCDate(d.getUTCDate() - n);
  d.setUTCHours(8, 0, 0, 0);
  return d;
};

async function seed() {
  console.log("▶ Seeding database…");

  // ── User ──────────────────────────────────────────────────────────────────
  await db
    .insert(users)
    .values({
      id: USER_ID,
      name: "Alex Thornton",
      dateOfBirth: "1985-04-22",
      createdAt: new Date("2024-01-01T00:00:00Z"),
    })
    .onConflictDoNothing();
  console.log("  ✓ user");

  // ── Devices ───────────────────────────────────────────────────────────────
  await db
    .insert(devices)
    .values([
      {
        id: DEVICE_1_ID,
        userId: USER_ID,
        name: "Omron HEM-7156T",
        manufacturer: "Omron Healthcare",
        bluetoothId: "AA:BB:CC:DD:EE:01",
        lastSyncedAt: daysAgo(0),
      },
      {
        id: DEVICE_2_ID,
        userId: USER_ID,
        name: "Withings BPM Connect",
        manufacturer: "Withings",
        bluetoothId: "AA:BB:CC:DD:EE:02",
        lastSyncedAt: daysAgo(3),
      },
    ])
    .onConflictDoNothing();
  console.log("  ✓ devices");

  // ── BP Readings ───────────────────────────────────────────────────────────
  await db
    .insert(bpReadings)
    .values([
      {
        // Normal: systolic 115, diastolic 74 → both below 120/80
        userId: USER_ID,
        systolic: 115,
        diastolic: 74,
        pulse: 68,
        measuredAt: daysAgo(0),
        arm: "left",
        position: "sitting",
        source: "bluetooth",
        deviceId: DEVICE_1_ID,
        notes: "Morning reading, rested 5 min beforehand.",
        timezone: "America/New_York",
      },
      {
        // Elevated: systolic 126, diastolic 77 → 120-129 with diastolic < 80
        userId: USER_ID,
        systolic: 126,
        diastolic: 77,
        pulse: 72,
        measuredAt: daysAgo(2),
        arm: "left",
        position: "sitting",
        source: "manual",
        deviceId: null,
        notes: "After two cups of coffee.",
        timezone: "America/New_York",
      },
      {
        // Stage 1: systolic 134, diastolic 86 → 130-139 / 80-89
        userId: USER_ID,
        systolic: 134,
        diastolic: 86,
        pulse: 78,
        measuredAt: daysAgo(3),
        arm: "right",
        position: "sitting",
        source: "bluetooth",
        deviceId: DEVICE_2_ID,
        notes: "End of a stressful work day.",
        timezone: "America/New_York",
      },
      {
        // Stage 2: systolic 152, diastolic 97 → ≥140 / ≥90
        userId: USER_ID,
        systolic: 152,
        diastolic: 97,
        pulse: 84,
        measuredAt: daysAgo(5),
        arm: "left",
        position: "standing",
        source: "manual",
        deviceId: null,
        notes: "Felt slightly lightheaded.",
        timezone: "America/New_York",
      },
      {
        // Crisis: systolic 184, diastolic 118 → >180 / approaching >120
        userId: USER_ID,
        systolic: 184,
        diastolic: 118,
        pulse: 96,
        measuredAt: daysAgo(6),
        arm: "left",
        position: "sitting",
        source: "bluetooth",
        deviceId: DEVICE_1_ID,
        notes: "Severe headache and chest tightness — sought medical attention.",
        timezone: "America/New_York",
      },
    ])
    .onConflictDoNothing();
  console.log("  ✓ bp_readings (Normal · Elevated · Stage 1 · Stage 2 · Crisis)");

  console.log("\n✅ Seed complete.");
  await pool.end();
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
