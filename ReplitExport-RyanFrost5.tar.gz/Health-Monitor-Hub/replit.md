# BP Tracker

A mobile health app for logging and monitoring blood pressure and heart rate (BPM). Users can log readings, view trends with charts, browse their history, and export data as CSV. On web/PWA, all data is encrypted with AES-256-GCM before being stored in IndexedDB.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Mobile: Expo (React Native) with Expo Router
- Fonts: Inter (400/500/600/700) via @expo-google-fonts/inter
- Storage: AsyncStorage (native) / Dexie.js + IndexedDB (web, with AES-256-GCM encryption)
- Encryption: Web Crypto API — AES-256-GCM + PBKDF2 (100,000 iterations, SHA-256)
- Charts: Custom SVG via react-native-svg
- Date/Time: @react-native-community/datetimepicker@8.4.4
- API: Express 5 (api-server artifact)
- DB: PostgreSQL + Drizzle ORM (not used by mobile in v1)
- Validation: Zod (zod/v4), drizzle-zod
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/mobile/` — Expo mobile app
  - `app/(tabs)/index.tsx` — Dashboard (charts, latest reading, averages)
  - `app/(tabs)/log.tsx` — Log entry form (date/time pickers, BP inputs, notes)
  - `app/(tabs)/history.tsx` — Filterable history list with color-coded cards
  - `app/(tabs)/settings.tsx` — Security (change password, lock), CSV export, BP reference guide
  - `context/BPContext.tsx` — CRUD for readings; drives setActiveKey when crypto state changes
  - `context/CryptoContext.tsx` — Native stub (always unlocked, null key)
  - `context/CryptoContext.web.tsx` — Web: PBKDF2 key derivation, AES-GCM session key in memory
  - `utils/crypto.ts` — `getPasswordStrength` helper (native/shared)
  - `utils/crypto.web.ts` — Web Crypto API: deriveKey, encryptData, decryptData, verifyKey
  - `utils/bpStorage.ts` — AsyncStorage adapter (native) + crypto stubs
  - `utils/bpStorage.web.ts` — Dexie v2 adapter with per-record AES-GCM encryption
  - `components/LockScreen.tsx` — First-use password setup + session unlock UI
  - `components/OfflineBanner.tsx` — Animated online/offline status banner (web only)
  - `utils/bpUtils.ts` — BP category logic, CSV generation, formatting helpers
  - `components/BPCard.tsx` — Reading card with category color-coding
  - `components/BPChart.tsx` — Custom SVG line chart
  - `components/StatCard.tsx` — Avg stat summary card
  - `constants/colors.ts` — Medical blue/teal palette with dark mode support

## Architecture decisions

- **Encryption (web only):** Each BP reading is individually encrypted with AES-256-GCM before being stored in IndexedDB via Dexie.js. The CryptoKey is derived from the user's master password using PBKDF2 (100,000 iterations, SHA-256, 256-bit key) and is held in memory only — never persisted. The salt and an encrypted verifier token are stored in the Dexie `meta` table. On native, the OS provides sandboxing/keychain protection; no app-level encryption is applied.
- **Platform-specific files:** Metro resolves `.web.ts` on web, `.ts` on native. `CryptoContext.web.tsx`, `bpStorage.web.ts`, and `crypto.web.ts` are web-only. Their native counterparts are stubs.
- **Session lifecycle:** On page load, `CryptoContext` checks if a salt exists in Dexie. If yes (`isSetup=true`), the lock screen is shown. Once the user enters the correct password, the derived `CryptoKey` is stored in React state (in-memory only). `BPContext` calls `setActiveKey()` whenever `cryptoKey` changes so the storage adapter encrypts/decrypts with the current key.
- All BP data is stored locally — no backend required for v1.
- BP categories follow AHA (American Heart Association) guidelines.
- Charts are built with raw react-native-svg (no chart library dependency) for reliability in Expo Go.
- Dark mode is driven by the device's system color scheme via `useColorScheme()`.
- `useColors()` hook spreads the active palette + adds `radius` — no hardcoded hex values in components.

## Security Notes

- **Choose a strong password** — the security of all your data depends on it. Use at least 12 characters with mixed case, numbers, and symbols.
- **There is no password recovery.** Encryption is 100% client-side. If you forget your master password, the data cannot be decrypted. Write your password down and store it securely.
- **The encryption key is never stored.** Only the PBKDF2 salt and an encrypted verifier are stored in IndexedDB. The derived AES-256-GCM `CryptoKey` lives in JavaScript memory for the session only and is wiped on page reload or when you lock the app.
- **Protect your device.** The encryption protects data at rest in IndexedDB, but if your device is unlocked and your browser is open, the key is active in memory.

## Product

- Log blood pressure (systolic/diastolic) and heart rate (BPM) with optional notes
- Dashboard with latest reading, line chart for 7d/30d/All trends, weekly averages
- History screen with filterable list by BP category (Normal, Elevated, Stage 1, Stage 2, Crisis)
- Settings with AES-256-GCM badge, Change Password, Lock App, CSV export, BP reference guide
- Color-coded entries based on AHA blood pressure categories
- Full dark/light mode support
- PWA: service worker, IndexedDB offline storage, install prompt
- Web: full client-side AES-256-GCM encryption with PBKDF2 key derivation

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Use `@react-native-community/datetimepicker@8.4.4` — v9+ is incompatible with current Expo SDK.
- `react-native-svg` must be installed for the chart component to work.
- Do NOT use the `uuid` package for ID generation — use `Date.now().toString() + Math.random().toString(36).substr(2, 9)` instead.
- `crypto.web.ts` is only imported by `bpStorage.web.ts` (web-only). `crypto.ts` (native) only contains `getPasswordStrength` — do NOT put Web Crypto API calls there.
- `CryptoKey` type doesn't exist on native — the shared `CryptoContextType` uses `unknown` for `cryptoKey`; the web implementation casts internally.
- Dexie DB is version 2: `readings: "id"` (encrypted blobs, only id indexed) + `meta: "key"`. The upgrade from v1 migrates plaintext records to `{id, payload: JSON.stringify(r), iv: ''}` format (empty iv = unencrypted/legacy). `setupEncryption()` then encrypts those records.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
