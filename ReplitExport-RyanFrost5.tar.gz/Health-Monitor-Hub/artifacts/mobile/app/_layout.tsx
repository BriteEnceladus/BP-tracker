import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { ErrorBoundary } from "@/components/ErrorBoundary";
import { LockScreen } from "@/components/LockScreen";
import { OfflineBanner } from "@/components/OfflineBanner";
import { BPProvider } from "@/context/BPContext";
import { CryptoProvider, useCrypto } from "@/context/CryptoContext";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

function AppGate() {
  const { isUnlocked, isSetup, isLoading } = useCrypto();

  if (isLoading) return null;

  if (!isUnlocked || !isSetup) {
    return <LockScreen />;
  }

  return (
    <BPProvider>
      <GestureHandlerRootView>
        <KeyboardProvider>
          <Stack screenOptions={{ headerBackTitle: "Back" }}>
            <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
          </Stack>
          <OfflineBanner />
        </KeyboardProvider>
      </GestureHandlerRootView>
    </BPProvider>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <CryptoProvider>
            <AppGate />
          </CryptoProvider>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
