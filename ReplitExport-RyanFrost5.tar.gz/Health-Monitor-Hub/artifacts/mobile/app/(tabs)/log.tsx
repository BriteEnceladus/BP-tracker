import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import DateTimePicker, { DateTimePickerEvent } from "@react-native-community/datetimepicker";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useColors } from "@/hooks/useColors";
import { useBP } from "@/context/BPContext";
import { router } from "expo-router";

export default function LogScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { addReading } = useBP();

  const now = new Date();
  const [date, setDate] = useState(now);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [systolic, setSystolic] = useState("");
  const [diastolic, setDiastolic] = useState("");
  const [bpm, setBpm] = useState("");
  const [notes, setNotes] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSaving, setIsSaving] = useState(false);

  const diastolicRef = useRef<TextInput>(null);
  const bpmRef = useRef<TextInput>(null);
  const notesRef = useRef<TextInput>(null);

  const webTopPadding = Platform.OS === "web" ? 67 : 0;

  const validate = useCallback(() => {
    const errs: Record<string, string> = {};
    const sys = parseInt(systolic, 10);
    const dia = parseInt(diastolic, 10);
    const hr = parseInt(bpm, 10);

    if (!systolic || isNaN(sys)) errs.systolic = "Required";
    else if (sys < 60 || sys > 250) errs.systolic = "Must be 60–250 mmHg";

    if (!diastolic || isNaN(dia)) errs.diastolic = "Required";
    else if (dia < 30 || dia > 150) errs.diastolic = "Must be 30–150 mmHg";

    if (!bpm || isNaN(hr)) errs.bpm = "Required";
    else if (hr < 30 || hr > 250) errs.bpm = "Must be 30–250 bpm";

    setErrors(errs);
    return Object.keys(errs).length === 0;
  }, [systolic, diastolic, bpm]);

  const handleSave = useCallback(async () => {
    if (!validate()) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }
    setIsSaving(true);
    try {
      await addReading({
        timestamp: date.toISOString(),
        systolic: parseInt(systolic, 10),
        diastolic: parseInt(diastolic, 10),
        bpm: parseInt(bpm, 10),
        notes: notes.trim() || undefined,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setSystolic("");
      setDiastolic("");
      setBpm("");
      setNotes("");
      setDate(new Date());
      setErrors({});
      router.push("/(tabs)");
    } catch {
      Alert.alert("Error", "Failed to save reading.");
    } finally {
      setIsSaving(false);
    }
  }, [validate, date, systolic, diastolic, bpm, notes, addReading]);

  const formatDate = (d: Date) =>
    d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });

  const formatTime = (d: Date) =>
    d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });

  const onDateChange = (_: DateTimePickerEvent, selected?: Date) => {
    setShowDatePicker(false);
    if (selected) {
      const updated = new Date(selected);
      updated.setHours(date.getHours(), date.getMinutes());
      setDate(updated);
    }
  };

  const onTimeChange = (_: DateTimePickerEvent, selected?: Date) => {
    setShowTimePicker(false);
    if (selected) {
      const updated = new Date(date);
      updated.setHours(selected.getHours(), selected.getMinutes());
      setDate(updated);
    }
  };

  const inputStyle = (key: string) => [
    styles.input,
    {
      backgroundColor: colors.card,
      borderColor: errors[key] ? colors.stage2 : colors.border,
      color: colors.foreground,
      borderRadius: colors.radius - 2,
      fontFamily: "Inter_400Regular",
    },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          {
            paddingTop: insets.top + 16 + webTopPadding,
            backgroundColor: colors.card,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <Text style={[styles.headerTitle, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>
          Log Reading
        </Text>
      </View>

      <KeyboardAwareScrollViewCompat
        bottomOffset={24}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.content,
          Platform.OS === "web" ? { paddingBottom: 34 + 84 } : { paddingBottom: 100 },
        ]}
      >
        <View style={[styles.section, { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
            Date & Time
          </Text>
          <Text style={[styles.sectionHint, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            Tap to change — you can log past readings by selecting an earlier date.
          </Text>

          <View style={styles.dateTimeRow}>
            <TouchableOpacity
              onPress={() => setShowDatePicker(true)}
              style={[styles.dateBtn, { backgroundColor: colors.muted, borderRadius: colors.radius - 2 }]}
              activeOpacity={0.7}
            >
              <Feather name="calendar" size={16} color={colors.primary} />
              <Text style={[styles.dateBtnText, { color: colors.foreground, fontFamily: "Inter_500Medium" }]}>
                {formatDate(date)}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => setShowTimePicker(true)}
              style={[styles.timeBtn, { backgroundColor: colors.muted, borderRadius: colors.radius - 2 }]}
              activeOpacity={0.7}
            >
              <Feather name="clock" size={16} color={colors.primary} />
              <Text style={[styles.dateBtnText, { color: colors.foreground, fontFamily: "Inter_500Medium" }]}>
                {formatTime(date)}
              </Text>
            </TouchableOpacity>
          </View>

          {showDatePicker && (
            <DateTimePicker
              value={date}
              mode="date"
              display={Platform.OS === "ios" ? "spinner" : "default"}
              maximumDate={new Date()}
              onChange={onDateChange}
            />
          )}
          {showTimePicker && (
            <DateTimePicker
              value={date}
              mode="time"
              display={Platform.OS === "ios" ? "spinner" : "default"}
              onChange={onTimeChange}
            />
          )}
        </View>

        <View style={[styles.section, { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
            Blood Pressure
          </Text>
          <Text style={[styles.sectionHint, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            Normal: below 120/80 mmHg
          </Text>

          <View style={styles.bpRow}>
            <View style={styles.inputGroup}>
              <Text style={[styles.inputLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>
                SYSTOLIC
              </Text>
              <TextInput
                style={inputStyle("systolic")}
                value={systolic}
                onChangeText={(v) => { setSystolic(v.replace(/\D/g, "")); setErrors((e) => ({ ...e, systolic: "" })); }}
                keyboardType="number-pad"
                placeholder="120"
                placeholderTextColor={colors.mutedForeground}
                maxLength={3}
                returnKeyType="next"
                onSubmitEditing={() => diastolicRef.current?.focus()}
                selectTextOnFocus
              />
              <Text style={[styles.inputUnit, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                mmHg
              </Text>
              {errors.systolic ? (
                <Text style={[styles.error, { color: colors.stage2, fontFamily: "Inter_400Regular" }]}>
                  {errors.systolic}
                </Text>
              ) : null}
            </View>

            <View style={styles.slashContainer}>
              <Text style={[styles.slash, { color: colors.border }]}>/</Text>
            </View>

            <View style={styles.inputGroup}>
              <Text style={[styles.inputLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>
                DIASTOLIC
              </Text>
              <TextInput
                ref={diastolicRef}
                style={inputStyle("diastolic")}
                value={diastolic}
                onChangeText={(v) => { setDiastolic(v.replace(/\D/g, "")); setErrors((e) => ({ ...e, diastolic: "" })); }}
                keyboardType="number-pad"
                placeholder="80"
                placeholderTextColor={colors.mutedForeground}
                maxLength={3}
                returnKeyType="next"
                onSubmitEditing={() => bpmRef.current?.focus()}
                selectTextOnFocus
              />
              <Text style={[styles.inputUnit, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                mmHg
              </Text>
              {errors.diastolic ? (
                <Text style={[styles.error, { color: colors.stage2, fontFamily: "Inter_400Regular" }]}>
                  {errors.diastolic}
                </Text>
              ) : null}
            </View>
          </View>
        </View>

        <View style={[styles.section, { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
            Heart Rate
          </Text>
          <Text style={[styles.sectionHint, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            Normal resting: 60–100 bpm
          </Text>

          <View style={styles.inputGroup}>
            <Text style={[styles.inputLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>
              BPM
            </Text>
            <TextInput
              ref={bpmRef}
              style={[inputStyle("bpm"), styles.bpmInput]}
              value={bpm}
              onChangeText={(v) => { setBpm(v.replace(/\D/g, "")); setErrors((e) => ({ ...e, bpm: "" })); }}
              keyboardType="number-pad"
              placeholder="72"
              placeholderTextColor={colors.mutedForeground}
              maxLength={3}
              returnKeyType="next"
              onSubmitEditing={() => notesRef.current?.focus()}
              selectTextOnFocus
            />
            <Text style={[styles.inputUnit, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
              beats per minute
            </Text>
            {errors.bpm ? (
              <Text style={[styles.error, { color: colors.stage2, fontFamily: "Inter_400Regular" }]}>
                {errors.bpm}
              </Text>
            ) : null}
          </View>
        </View>

        <View style={[styles.section, { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
            Notes
            <Text style={[styles.optional, { color: colors.mutedForeground }]}> (optional)</Text>
          </Text>

          <TextInput
            ref={notesRef}
            style={[
              styles.notesInput,
              {
                backgroundColor: colors.muted,
                borderColor: colors.border,
                color: colors.foreground,
                borderRadius: colors.radius - 2,
                fontFamily: "Inter_400Regular",
              },
            ]}
            value={notes}
            onChangeText={setNotes}
            placeholder="e.g., after workout, felt dizzy, took medication..."
            placeholderTextColor={colors.mutedForeground}
            multiline
            numberOfLines={3}
            textAlignVertical="top"
          />
        </View>

        <TouchableOpacity
          style={[
            styles.saveBtn,
            {
              backgroundColor: isSaving ? colors.mutedForeground : colors.primary,
              borderRadius: colors.radius,
            },
          ]}
          onPress={handleSave}
          disabled={isSaving}
          activeOpacity={0.85}
        >
          <Feather name="check-circle" size={20} color={colors.primaryForeground} />
          <Text style={[styles.saveBtnText, { color: colors.primaryForeground, fontFamily: "Inter_600SemiBold" }]}>
            {isSaving ? "Saving..." : "Save Reading"}
          </Text>
        </TouchableOpacity>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 26,
  },
  content: {
    paddingTop: 16,
    paddingHorizontal: 16,
    gap: 12,
  },
  section: {
    padding: 16,
    borderWidth: 1,
  },
  sectionTitle: {
    fontSize: 15,
    marginBottom: 4,
  },
  sectionHint: {
    fontSize: 12,
    marginBottom: 12,
  },
  optional: {
    fontSize: 13,
    fontWeight: "400",
  },
  dateTimeRow: {
    flexDirection: "row",
    gap: 10,
    marginTop: 4,
  },
  dateBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
  },
  timeBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
  },
  dateBtnText: {
    fontSize: 14,
  },
  bpRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 4,
  },
  slashContainer: {
    marginTop: 32,
    paddingHorizontal: 4,
  },
  slash: {
    fontSize: 28,
  },
  inputGroup: {
    flex: 1,
  },
  inputLabel: {
    fontSize: 10,
    letterSpacing: 1,
    marginBottom: 6,
  },
  input: {
    borderWidth: 1.5,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 24,
    textAlign: "center",
  },
  bpmInput: {
    width: "50%",
  },
  inputUnit: {
    fontSize: 11,
    textAlign: "center",
    marginTop: 4,
  },
  error: {
    fontSize: 11,
    marginTop: 4,
  },
  notesInput: {
    borderWidth: 1.5,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    minHeight: 80,
    marginTop: 4,
  },
  saveBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingVertical: 16,
    marginTop: 4,
  },
  saveBtnText: {
    fontSize: 17,
  },
});
