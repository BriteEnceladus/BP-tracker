import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  Platform,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useBP } from "@/context/BPContext";
import { useCrypto } from "@/context/CryptoContext";
import { useInstallPrompt } from "@/hooks/useInstallPrompt";
import { readingsToCSV } from "@/utils/bpUtils";
import { getPasswordStrength } from "@/utils/crypto";
import { CSVImportModal } from "@/components/CSVImportModal";

const BP_CATEGORIES = [
  {
    label: "Normal",
    range: "< 120/80",
    colorKey: "normal" as const,
    description: "Maintain healthy lifestyle",
  },
  {
    label: "Elevated",
    range: "120–129 / < 80",
    colorKey: "elevated" as const,
    description: "Lifestyle changes recommended",
  },
  {
    label: "High BP Stage 1",
    range: "130–139 / 80–89",
    colorKey: "stage1" as const,
    description: "Consult a doctor",
  },
  {
    label: "High BP Stage 2",
    range: "≥ 140 / ≥ 90",
    colorKey: "stage2" as const,
    description: "Medical treatment needed",
  },
  {
    label: "Hypertensive Crisis",
    range: "> 180 / > 120",
    colorKey: "crisis" as const,
    description: "Seek emergency care",
  },
];

function ChangePasswordModal({
  visible,
  onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) {
  const colors = useColors();
  const { changePassword } = useCrypto();
  const [oldPwd, setOldPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const [showOld, setShowOld] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const strength = getPasswordStrength(newPwd);
  const passwordsMatch = newPwd === confirmPwd;
  const canSubmit =
    !isLoading &&
    oldPwd.length > 0 &&
    newPwd.length >= 8 &&
    passwordsMatch &&
    confirmPwd.length > 0;

  const resetAndClose = () => {
    setOldPwd("");
    setNewPwd("");
    setConfirmPwd("");
    setError("");
    setIsLoading(false);
    onClose();
  };

  const handleSubmit = async () => {
    if (!canSubmit) return;
    setIsLoading(true);
    setError("");
    try {
      await changePassword(oldPwd, newPwd);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      resetAndClose();
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Unknown error";
      if (msg.includes("Incorrect")) {
        setError("Current password is incorrect.");
      } else {
        setError("Failed to change password. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={resetAndClose}>
      <View style={styles.modalOverlay}>
        <View
          style={[
            styles.modalCard,
            {
              backgroundColor: colors.card,
              borderRadius: colors.radius * 1.5,
              borderColor: colors.border,
            },
          ]}
        >
          <View style={styles.modalHeader}>
            <Text
              style={[styles.modalTitle, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}
            >
              Change Password
            </Text>
            <TouchableOpacity onPress={resetAndClose}>
              <Feather name="x" size={22} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>

          <Text
            style={[
              styles.modalSub,
              { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
            ]}
          >
            All existing readings will be re-encrypted with your new password.
          </Text>

          {[
            {
              label: "Current password",
              value: oldPwd,
              onChangeText: (t: string) => { setOldPwd(t); setError(""); },
              show: showOld,
              toggleShow: () => setShowOld((v) => !v),
            },
            {
              label: "New password",
              value: newPwd,
              onChangeText: (t: string) => { setNewPwd(t); setError(""); },
              show: showNew,
              toggleShow: () => setShowNew((v) => !v),
            },
            {
              label: "Confirm new password",
              value: confirmPwd,
              onChangeText: (t: string) => { setConfirmPwd(t); setError(""); },
              show: showNew,
              toggleShow: () => setShowNew((v) => !v),
            },
          ].map(({ label, value, onChangeText, show, toggleShow }, i) => (
            <View
              key={i}
              style={[
                styles.inputWrap,
                {
                  backgroundColor: colors.background,
                  borderColor:
                    i === 2 && confirmPwd.length > 0 && !passwordsMatch
                      ? colors.destructive
                      : colors.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <TextInput
                style={[
                  styles.modalInput,
                  { color: colors.foreground, fontFamily: "Inter_400Regular" },
                ]}
                placeholder={label}
                placeholderTextColor={colors.mutedForeground}
                secureTextEntry={!show}
                value={value}
                onChangeText={onChangeText}
                autoCapitalize="none"
                autoCorrect={false}
              />
              <TouchableOpacity onPress={toggleShow} style={styles.eyeBtn}>
                <Feather
                  name={show ? "eye-off" : "eye"}
                  size={16}
                  color={colors.mutedForeground}
                />
              </TouchableOpacity>
            </View>
          ))}

          {newPwd.length > 0 && (
            <View style={styles.strengthWrap}>
              <View style={[styles.strengthBar, { backgroundColor: colors.border }]}>
                {[0, 1, 2, 3, 4].map((i) => (
                  <View
                    key={i}
                    style={[
                      styles.strengthSegment,
                      {
                        backgroundColor:
                          i <= strength.score ? strength.color : "transparent",
                      },
                    ]}
                  />
                ))}
              </View>
              <Text
                style={[
                  styles.strengthLabel,
                  { color: strength.color, fontFamily: "Inter_500Medium" },
                ]}
              >
                {strength.label} — {strength.feedback}
              </Text>
            </View>
          )}

          {error ? (
            <View style={[styles.errorWrap, { backgroundColor: colors.destructive + "18" }]}>
              <Feather name="alert-circle" size={13} color={colors.destructive} />
              <Text
                style={[
                  styles.errorText,
                  { color: colors.destructive, fontFamily: "Inter_400Regular" },
                ]}
              >
                {error}
              </Text>
            </View>
          ) : null}

          <TouchableOpacity
            style={[
              styles.modalBtn,
              {
                backgroundColor: canSubmit ? colors.primary : colors.muted,
                borderRadius: colors.radius,
              },
            ]}
            onPress={handleSubmit}
            disabled={!canSubmit}
            activeOpacity={0.8}
          >
            {isLoading ? (
              <ActivityIndicator color={colors.primaryForeground} />
            ) : (
              <Text
                style={[
                  styles.modalBtnText,
                  {
                    color: canSubmit ? colors.primaryForeground : colors.mutedForeground,
                    fontFamily: "Inter_600SemiBold",
                  },
                ]}
              >
                Update Password
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { readings, clearAll } = useBP();
  const {
    isSetup,
    isUnlocked,
    lock,
    biometricSupported,
    biometricEnrolled,
    enrollBiometric,
    removeBiometric,
  } = useCrypto();
  const [exporting, setExporting] = useState(false);
  const [showIOSInstructions, setShowIOSInstructions] = useState(false);
  const [showChangePwd, setShowChangePwd] = useState(false);
  const [showImportCSV, setShowImportCSV] = useState(false);
  const [bioLoading, setBioLoading] = useState(false);
  const [bioError, setBioError] = useState("");
  const { isInstallable, isInstalled, isIOS, promptInstall } = useInstallPrompt();
  const webTopPadding = Platform.OS === "web" ? 67 : 0;

  const showInstallSection =
    Platform.OS === "web" && (isInstallable || isIOS || isInstalled);
  const showSecuritySection = Platform.OS === "web" && isSetup && isUnlocked;

  const categoryColors = {
    normal: colors.normal,
    elevated: colors.elevated,
    stage1: colors.stage1,
    stage2: colors.stage2,
    crisis: colors.crisis,
  };

  const handleExportCSV = async () => {
    if (readings.length === 0) {
      Alert.alert("No data", "Log some readings first before exporting.");
      return;
    }
    setExporting(true);
    try {
      const csv = readingsToCSV(readings);
      if (Platform.OS === "web") {
        const blob = new Blob([csv], { type: "text/csv" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "bp_readings.csv";
        a.click();
        URL.revokeObjectURL(url);
      } else {
        await Share.share({ message: csv, title: "BP Readings Export" });
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch {
      Alert.alert("Export failed", "Could not export data.");
    } finally {
      setExporting(false);
    }
  };

  const handleClearData = () => {
    Alert.alert(
      "Clear All Data",
      `This will permanently delete all ${readings.length} readings and your encryption key. This cannot be undone.`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete All",
          style: "destructive",
          onPress: async () => {
            await clearAll();
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          },
        },
      ]
    );
  };

  const handleInstall = async () => {
    if (isIOS && !isInstallable) {
      setShowIOSInstructions(true);
      return;
    }
    const accepted = await promptInstall();
    if (accepted) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const handleLock = () => {
    lock();
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleEnrollBiometric = async () => {
    setBioLoading(true);
    setBioError("");
    try {
      await enrollBiometric();
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      if (msg.toLowerCase().includes("cancel")) {
        setBioError("Enrollment cancelled.");
      } else if (msg.toLowerCase().includes("not allowed") || msg.toLowerCase().includes("cross-origin")) {
        setBioError("Biometrics require the app to be opened directly (not in an embedded frame). Try opening in a new tab.");
      } else {
        setBioError("Enrollment failed. Ensure your device has biometrics set up.");
      }
    } finally {
      setBioLoading(false);
    }
  };

  const handleRemoveBiometric = () => {
    Alert.alert(
      "Remove Biometric Unlock",
      "You will need to enter your password each time you unlock the app.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Remove",
          style: "destructive",
          onPress: async () => {
            await removeBiometric();
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          },
        },
      ]
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          {
            paddingTop: insets.top + 16 + webTopPadding,
            backgroundColor: colors.card,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <View style={styles.headerRow}>
          <Text
            style={[styles.headerTitle, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}
          >
            Settings
          </Text>
          {showSecuritySection && (
            <View style={[styles.encBadge, { backgroundColor: colors.normal + "18" }]}>
              <Feather name="shield" size={11} color={colors.normal} />
              <Text
                style={[
                  styles.encBadgeText,
                  { color: colors.normal, fontFamily: "Inter_600SemiBold" },
                ]}
              >
                Encrypted
              </Text>
            </View>
          )}
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.content,
          Platform.OS === "web" ? { paddingBottom: 34 + 84 } : { paddingBottom: 100 },
        ]}
      >
        {showSecuritySection && (
          <>
            <View style={styles.sectionHeader}>
              <Text
                style={[
                  styles.sectionLabel,
                  { color: colors.mutedForeground, fontFamily: "Inter_500Medium" },
                ]}
              >
                SECURITY
              </Text>
            </View>
            <View
              style={[
                styles.card,
                {
                  backgroundColor: colors.card,
                  borderRadius: colors.radius,
                  borderColor: colors.border,
                },
              ]}
            >
              <View style={styles.row}>
                <View style={[styles.iconBg, { backgroundColor: colors.normal + "22" }]}>
                  <Feather name="shield" size={18} color={colors.normal} />
                </View>
                <View style={styles.rowContent}>
                  <Text
                    style={[
                      styles.rowTitle,
                      { color: colors.foreground, fontFamily: "Inter_500Medium" },
                    ]}
                  >
                    AES-256-GCM Encrypted
                  </Text>
                  <Text
                    style={[
                      styles.rowSub,
                      { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
                    ]}
                  >
                    PBKDF2 key derivation · 100,000 iterations
                  </Text>
                </View>
              </View>

              <View style={[styles.separator, { backgroundColor: colors.border }]} />

              <TouchableOpacity
                style={styles.row}
                onPress={() => setShowChangePwd(true)}
                activeOpacity={0.7}
              >
                <View style={[styles.iconBg, { backgroundColor: colors.primary + "22" }]}>
                  <Feather name="key" size={18} color={colors.primary} />
                </View>
                <View style={styles.rowContent}>
                  <Text
                    style={[
                      styles.rowTitle,
                      { color: colors.foreground, fontFamily: "Inter_500Medium" },
                    ]}
                  >
                    Change Password
                  </Text>
                  <Text
                    style={[
                      styles.rowSub,
                      { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
                    ]}
                  >
                    Re-encrypt all readings with a new password
                  </Text>
                </View>
                <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
              </TouchableOpacity>

              <View style={[styles.separator, { backgroundColor: colors.border }]} />

              <TouchableOpacity style={styles.row} onPress={handleLock} activeOpacity={0.7}>
                <View style={[styles.iconBg, { backgroundColor: colors.accent + "22" }]}>
                  <Feather name="lock" size={18} color={colors.accent} />
                </View>
                <View style={styles.rowContent}>
                  <Text
                    style={[
                      styles.rowTitle,
                      { color: colors.foreground, fontFamily: "Inter_500Medium" },
                    ]}
                  >
                    Lock App
                  </Text>
                  <Text
                    style={[
                      styles.rowSub,
                      { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
                    ]}
                  >
                    Require password to access data again
                  </Text>
                </View>
                <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
              </TouchableOpacity>

              <View style={[styles.separator, { backgroundColor: colors.border }]} />

              {biometricSupported ? (
                biometricEnrolled ? (
                  <View>
                    <View style={styles.row}>
                      <View style={[styles.iconBg, { backgroundColor: colors.normal + "22" }]}>
                        <Feather name="smartphone" size={18} color={colors.normal} />
                      </View>
                      <View style={styles.rowContent}>
                        <Text
                          style={[
                            styles.rowTitle,
                            { color: colors.foreground, fontFamily: "Inter_500Medium" },
                          ]}
                        >
                          Biometric Unlock Enabled
                        </Text>
                        <Text
                          style={[
                            styles.rowSub,
                            { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
                          ]}
                        >
                          Fingerprint / Face ID active
                        </Text>
                      </View>
                      <TouchableOpacity
                        onPress={handleRemoveBiometric}
                        style={[
                          styles.bioRemoveBtn,
                          { backgroundColor: colors.destructive + "18", borderRadius: 8 },
                        ]}
                        activeOpacity={0.7}
                      >
                        <Text
                          style={[
                            styles.bioRemoveText,
                            { color: colors.destructive, fontFamily: "Inter_500Medium" },
                          ]}
                        >
                          Remove
                        </Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ) : (
                  <View>
                    <TouchableOpacity
                      style={styles.row}
                      onPress={handleEnrollBiometric}
                      disabled={bioLoading}
                      activeOpacity={0.7}
                    >
                      <View
                        style={[
                          styles.iconBg,
                          {
                            backgroundColor: bioLoading
                              ? colors.muted
                              : colors.primary + "22",
                          },
                        ]}
                      >
                        {bioLoading ? (
                          <ActivityIndicator size="small" color={colors.primary} />
                        ) : (
                          <Feather name="smartphone" size={18} color={colors.primary} />
                        )}
                      </View>
                      <View style={styles.rowContent}>
                        <Text
                          style={[
                            styles.rowTitle,
                            { color: colors.foreground, fontFamily: "Inter_500Medium" },
                          ]}
                        >
                          Enable Biometric Unlock
                        </Text>
                        <Text
                          style={[
                            styles.rowSub,
                            { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
                          ]}
                        >
                          {bioLoading
                            ? "Waiting for biometric…"
                            : "Faster access with fingerprint or Face ID"}
                        </Text>
                      </View>
                      {!bioLoading && (
                        <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
                      )}
                    </TouchableOpacity>
                    {bioError ? (
                      <View
                        style={[
                          styles.bioErrorWrap,
                          {
                            backgroundColor: colors.destructive + "12",
                            borderColor: colors.destructive + "30",
                          },
                        ]}
                      >
                        <Feather name="alert-circle" size={13} color={colors.destructive} />
                        <Text
                          style={[
                            styles.bioErrorText,
                            { color: colors.destructive, fontFamily: "Inter_400Regular" },
                          ]}
                        >
                          {bioError}
                        </Text>
                      </View>
                    ) : null}
                  </View>
                )
              ) : (
                <View style={styles.row}>
                  <View style={[styles.iconBg, { backgroundColor: colors.muted }]}>
                    <Feather name="smartphone" size={18} color={colors.mutedForeground} />
                  </View>
                  <View style={styles.rowContent}>
                    <Text
                      style={[
                        styles.rowTitle,
                        { color: colors.mutedForeground, fontFamily: "Inter_500Medium" },
                      ]}
                    >
                      Biometrics Unavailable
                    </Text>
                    <Text
                      style={[
                        styles.rowSub,
                        { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
                      ]}
                    >
                      Not supported on this device or browser
                    </Text>
                  </View>
                </View>
              )}
            </View>
          </>
        )}

        {showInstallSection && (
          <>
            <View style={styles.sectionHeader}>
              <Text
                style={[
                  styles.sectionLabel,
                  { color: colors.mutedForeground, fontFamily: "Inter_500Medium" },
                ]}
              >
                INSTALL APP
              </Text>
            </View>
            <View
              style={[
                styles.card,
                {
                  backgroundColor: colors.card,
                  borderRadius: colors.radius,
                  borderColor: colors.border,
                },
              ]}
            >
              {isInstalled ? (
                <View style={styles.row}>
                  <View style={[styles.iconBg, { backgroundColor: colors.normal + "22" }]}>
                    <Feather name="check-circle" size={18} color={colors.normal} />
                  </View>
                  <View style={styles.rowContent}>
                    <Text
                      style={[
                        styles.rowTitle,
                        { color: colors.foreground, fontFamily: "Inter_500Medium" },
                      ]}
                    >
                      App Installed
                    </Text>
                    <Text
                      style={[
                        styles.rowSub,
                        { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
                      ]}
                    >
                      BP Tracker is on your home screen
                    </Text>
                  </View>
                </View>
              ) : (
                <TouchableOpacity
                  style={styles.row}
                  onPress={handleInstall}
                  activeOpacity={0.7}
                >
                  <View style={[styles.iconBg, { backgroundColor: colors.accent + "22" }]}>
                    <Feather name="smartphone" size={18} color={colors.accent} />
                  </View>
                  <View style={styles.rowContent}>
                    <Text
                      style={[
                        styles.rowTitle,
                        { color: colors.foreground, fontFamily: "Inter_500Medium" },
                      ]}
                    >
                      {isIOS ? "Add to Home Screen" : "Install App"}
                    </Text>
                    <Text
                      style={[
                        styles.rowSub,
                        { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
                      ]}
                    >
                      {isIOS
                        ? "Use Safari's Share menu to install"
                        : "Install for offline use & fast access"}
                    </Text>
                  </View>
                  <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
                </TouchableOpacity>
              )}
            </View>
          </>
        )}

        <View style={styles.sectionHeader}>
          <Text
            style={[
              styles.sectionLabel,
              { color: colors.mutedForeground, fontFamily: "Inter_500Medium" },
            ]}
          >
            DATA
          </Text>
        </View>
        <View
          style={[
            styles.card,
            {
              backgroundColor: colors.card,
              borderRadius: colors.radius,
              borderColor: colors.border,
            },
          ]}
        >
          <TouchableOpacity
            style={styles.row}
            onPress={handleExportCSV}
            disabled={exporting}
            activeOpacity={0.7}
          >
            <View style={[styles.iconBg, { backgroundColor: colors.primary + "22" }]}>
              <Feather name="download" size={18} color={colors.primary} />
            </View>
            <View style={styles.rowContent}>
              <Text
                style={[
                  styles.rowTitle,
                  { color: colors.foreground, fontFamily: "Inter_500Medium" },
                ]}
              >
                Export as CSV
              </Text>
              <Text
                style={[
                  styles.rowSub,
                  { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
                ]}
              >
                {readings.length} readings available
              </Text>
            </View>
            <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
          </TouchableOpacity>

          <View style={[styles.separator, { backgroundColor: colors.border }]} />

          <TouchableOpacity
            style={styles.row}
            onPress={() => setShowImportCSV(true)}
            activeOpacity={0.7}
          >
            <View style={[styles.iconBg, { backgroundColor: colors.accent + "22" }]}>
              <Feather name="upload" size={18} color={colors.accent} />
            </View>
            <View style={styles.rowContent}>
              <Text
                style={[
                  styles.rowTitle,
                  { color: colors.foreground, fontFamily: "Inter_500Medium" },
                ]}
              >
                Import from CSV
              </Text>
              <Text
                style={[
                  styles.rowSub,
                  { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
                ]}
              >
                Bulk-import historical readings from a file
              </Text>
            </View>
            <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
          </TouchableOpacity>

          <View style={[styles.separator, { backgroundColor: colors.border }]} />

          <TouchableOpacity style={styles.row} onPress={handleClearData} activeOpacity={0.7}>
            <View style={[styles.iconBg, { backgroundColor: colors.destructive + "22" }]}>
              <Feather name="trash-2" size={18} color={colors.destructive} />
            </View>
            <View style={styles.rowContent}>
              <Text
                style={[
                  styles.rowTitle,
                  { color: colors.destructive, fontFamily: "Inter_500Medium" },
                ]}
              >
                Clear All Data
              </Text>
              <Text
                style={[
                  styles.rowSub,
                  { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
                ]}
              >
                Permanently delete all readings
              </Text>
            </View>
            <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
          </TouchableOpacity>
        </View>

        <View style={styles.sectionHeader}>
          <Text
            style={[
              styles.sectionLabel,
              { color: colors.mutedForeground, fontFamily: "Inter_500Medium" },
            ]}
          >
            BP REFERENCE GUIDE
          </Text>
        </View>
        <View
          style={[
            styles.card,
            {
              backgroundColor: colors.card,
              borderRadius: colors.radius,
              borderColor: colors.border,
              overflow: "hidden",
            },
          ]}
        >
          {BP_CATEGORIES.map((cat, i) => {
            const color = categoryColors[cat.colorKey];
            return (
              <View key={cat.label}>
                <View
                  style={[styles.categoryRow, { borderLeftColor: color, borderLeftWidth: 4 }]}
                >
                  <View style={styles.categoryLeft}>
                    <View style={[styles.categoryDot, { backgroundColor: color + "22" }]}>
                      <View style={[styles.categoryDotInner, { backgroundColor: color }]} />
                    </View>
                    <View>
                      <Text
                        style={[
                          styles.categoryName,
                          { color: colors.foreground, fontFamily: "Inter_600SemiBold" },
                        ]}
                      >
                        {cat.label}
                      </Text>
                      <Text
                        style={[
                          styles.categoryDesc,
                          { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
                        ]}
                      >
                        {cat.description}
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.rangeTag, { backgroundColor: color + "22", borderRadius: 8 }]}>
                    <Text
                      style={[styles.rangeText, { color, fontFamily: "Inter_600SemiBold" }]}
                    >
                      {cat.range}
                    </Text>
                  </View>
                </View>
                {i < BP_CATEGORIES.length - 1 && (
                  <View style={[styles.separator, { backgroundColor: colors.border }]} />
                )}
              </View>
            );
          })}
        </View>

        <View style={styles.sectionHeader}>
          <Text
            style={[
              styles.sectionLabel,
              { color: colors.mutedForeground, fontFamily: "Inter_500Medium" },
            ]}
          >
            ABOUT
          </Text>
        </View>
        <View
          style={[
            styles.card,
            {
              backgroundColor: colors.card,
              borderRadius: colors.radius,
              borderColor: colors.border,
            },
          ]}
        >
          <View style={styles.aboutContent}>
            <Text
              style={[styles.appName, { color: colors.primary, fontFamily: "Inter_700Bold" }]}
            >
              BP Tracker
            </Text>
            <Text
              style={[
                styles.aboutText,
                { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
              ]}
            >
              Track your blood pressure and heart rate with ease. Based on AHA (American Heart
              Association) guidelines. All data is stored and encrypted locally on your device.
            </Text>
            <Text
              style={[
                styles.disclaimer,
                { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
              ]}
            >
              This app is for personal tracking only and is not a medical device. Always consult a
              healthcare professional for medical advice.
            </Text>
          </View>
        </View>
      </ScrollView>

      <ChangePasswordModal visible={showChangePwd} onClose={() => setShowChangePwd(false)} />

      <CSVImportModal visible={showImportCSV} onClose={() => setShowImportCSV(false)} />

      <Modal
        visible={showIOSInstructions}
        transparent
        animationType="slide"
        onRequestClose={() => setShowIOSInstructions(false)}
      >
        <View style={styles.modalOverlay}>
          <View
            style={[
              styles.modalCard,
              {
                backgroundColor: colors.card,
                borderRadius: colors.radius * 1.5,
                borderColor: colors.border,
              },
            ]}
          >
            <View style={styles.modalHeader}>
              <Text
                style={[
                  styles.modalTitle,
                  { color: colors.foreground, fontFamily: "Inter_700Bold" },
                ]}
              >
                Add to Home Screen
              </Text>
              <TouchableOpacity onPress={() => setShowIOSInstructions(false)}>
                <Feather name="x" size={22} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>

            <Text
              style={[
                styles.modalSub,
                { color: colors.mutedForeground, fontFamily: "Inter_400Regular" },
              ]}
            >
              Follow these steps in Safari to install BP Tracker on your iPhone or iPad:
            </Text>

            {[
              "Tap the Share button at the bottom of Safari (box with arrow pointing up)",
              'Scroll down and tap "Add to Home Screen"',
              'Tap "Add" in the top-right corner',
              "BP Tracker will appear on your home screen like a native app",
            ].map((text, idx) => (
              <View key={idx} style={styles.stepRow}>
                <View style={[styles.stepBadge, { backgroundColor: colors.primary }]}>
                  <Text
                    style={[
                      styles.stepNum,
                      { color: colors.primaryForeground, fontFamily: "Inter_700Bold" },
                    ]}
                  >
                    {idx + 1}
                  </Text>
                </View>
                <Text
                  style={[
                    styles.stepText,
                    { color: colors.foreground, fontFamily: "Inter_400Regular" },
                  ]}
                >
                  {text}
                </Text>
              </View>
            ))}

            <TouchableOpacity
              style={[
                styles.modalBtn,
                { backgroundColor: colors.primary, borderRadius: colors.radius },
              ]}
              onPress={() => setShowIOSInstructions(false)}
            >
              <Text
                style={[
                  styles.modalBtnText,
                  { color: colors.primaryForeground, fontFamily: "Inter_600SemiBold" },
                ]}
              >
                Got it
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1 },
  headerRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  headerTitle: { fontSize: 26 },
  encBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
  },
  encBadgeText: { fontSize: 11 },
  content: { paddingTop: 8 },
  sectionHeader: { paddingHorizontal: 20, paddingTop: 20, paddingBottom: 8 },
  sectionLabel: { fontSize: 11, letterSpacing: 1.5 },
  card: { marginHorizontal: 16, borderWidth: 1, overflow: "hidden" },
  row: { flexDirection: "row", alignItems: "center", padding: 16, gap: 12 },
  iconBg: {
    width: 38,
    height: 38,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  rowContent: { flex: 1, gap: 2 },
  rowTitle: { fontSize: 15 },
  rowSub: { fontSize: 12 },
  separator: { height: 1, marginLeft: 66 },
  categoryRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 12,
    paddingHorizontal: 14,
    gap: 12,
  },
  categoryLeft: { flexDirection: "row", alignItems: "center", gap: 10, flex: 1 },
  categoryDot: { width: 32, height: 32, borderRadius: 16, justifyContent: "center", alignItems: "center" },
  categoryDotInner: { width: 12, height: 12, borderRadius: 6 },
  categoryName: { fontSize: 13 },
  categoryDesc: { fontSize: 11, marginTop: 1 },
  rangeTag: { paddingHorizontal: 8, paddingVertical: 4 },
  rangeText: { fontSize: 11 },
  aboutContent: { padding: 16, gap: 8 },
  appName: { fontSize: 20 },
  aboutText: { fontSize: 13, lineHeight: 20 },
  disclaimer: { fontSize: 11, lineHeight: 18, marginTop: 4 },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    justifyContent: "flex-end",
    padding: 16,
    paddingBottom: 32,
  },
  modalCard: { padding: 24, borderWidth: 1, gap: 14 },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  modalTitle: { fontSize: 20 },
  modalSub: { fontSize: 14, lineHeight: 20 },
  inputWrap: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    paddingHorizontal: 14,
    height: 48,
  },
  modalInput: { flex: 1, fontSize: 14 },
  eyeBtn: { padding: 4 },
  strengthWrap: { gap: 4 },
  strengthBar: {
    flexDirection: "row",
    height: 4,
    borderRadius: 2,
    gap: 3,
    overflow: "hidden",
  },
  strengthSegment: { flex: 1, height: "100%", borderRadius: 3 },
  strengthLabel: { fontSize: 12 },
  errorWrap: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 9,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  errorText: { fontSize: 13, flex: 1 },
  modalBtn: { paddingVertical: 14, alignItems: "center", marginTop: 4 },
  modalBtnText: { fontSize: 16 },
  stepRow: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  stepBadge: { width: 26, height: 26, borderRadius: 13, justifyContent: "center", alignItems: "center", flexShrink: 0 },
  stepNum: { fontSize: 12 },
  stepText: { fontSize: 14, lineHeight: 20, flex: 1 },
  bioRemoveBtn: { paddingHorizontal: 12, paddingVertical: 6 },
  bioRemoveText: { fontSize: 13 },
  bioErrorWrap: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
    marginHorizontal: 0,
    borderTopWidth: 1,
  },
  bioErrorText: { fontSize: 12, flex: 1, lineHeight: 18 },
});
