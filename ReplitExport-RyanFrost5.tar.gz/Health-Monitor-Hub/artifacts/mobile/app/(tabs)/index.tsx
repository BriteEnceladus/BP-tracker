import React, { useMemo, useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useBP } from "@/context/BPContext";
import { BPCard } from "@/components/BPCard";
import { BPChart } from "@/components/BPChart";
import { StatCard } from "@/components/StatCard";
import {
  getBPCategory,
  getCategoryLabel,
  getAverages,
  getReadingsForDays,
} from "@/utils/bpUtils";

type Range = 7 | 30 | 0;

export default function DashboardScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { readings, isLoading } = useBP();
  const [range, setRange] = useState<Range>(7);

  const sortedReadings = useMemo(
    () => [...readings].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()),
    [readings]
  );

  const latest = sortedReadings[0] ?? null;

  const filteredReadings = useMemo(() => {
    if (range === 0) return readings;
    return getReadingsForDays(readings, range);
  }, [readings, range]);

  const averages = useMemo(() => getAverages(filteredReadings), [filteredReadings]);

  const latestCategory = latest ? getBPCategory(latest.systolic, latest.diastolic) : null;

  const categoryColorMap = {
    normal: colors.normal,
    elevated: colors.elevated,
    stage1: colors.stage1,
    stage2: colors.stage2,
    crisis: colors.crisis,
  };

  const webTopPadding = Platform.OS === "web" ? 67 : 0;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          {
            paddingTop: insets.top + 16 + webTopPadding,
            backgroundColor: colors.card,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <View>
          <Text style={[styles.greeting, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            Your Health Dashboard
          </Text>
          <Text style={[styles.headerTitle, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>
            BP Tracker
          </Text>
        </View>
        <TouchableOpacity
          style={[styles.addBtn, { backgroundColor: colors.primary, borderRadius: colors.radius }]}
          onPress={() => router.push("/(tabs)/log")}
          activeOpacity={0.85}
        >
          <Feather name="plus" size={20} color={colors.primaryForeground} />
        </TouchableOpacity>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.content,
          Platform.OS === "web" ? { paddingBottom: 34 + 84 } : { paddingBottom: 100 },
        ]}
      >
        {latest ? (
          <View style={styles.latestSection}>
            <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
              Latest Reading
            </Text>
            <BPCard reading={latest} />
          </View>
        ) : (
          <View
            style={[
              styles.emptyHero,
              { backgroundColor: colors.card, borderRadius: colors.radius, borderColor: colors.border },
            ]}
          >
            <Feather name="activity" size={40} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
              No readings yet
            </Text>
            <Text style={[styles.emptySubtitle, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
              Tap the + button to log your first blood pressure reading
            </Text>
            <TouchableOpacity
              style={[styles.logBtn, { backgroundColor: colors.primary, borderRadius: colors.radius }]}
              onPress={() => router.push("/(tabs)/log")}
            >
              <Text style={[styles.logBtnText, { color: colors.primaryForeground, fontFamily: "Inter_600SemiBold" }]}>
                Log First Reading
              </Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.rangeSection}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
            Trends
          </Text>
          <View style={[styles.rangeSelector, { backgroundColor: colors.muted, borderRadius: 24 }]}>
            {([7, 30, 0] as Range[]).map((r) => (
              <Pressable
                key={r}
                onPress={() => setRange(r)}
                style={[
                  styles.rangeBtn,
                  { borderRadius: 20 },
                  range === r && { backgroundColor: colors.primary },
                ]}
              >
                <Text
                  style={[
                    styles.rangeBtnText,
                    {
                      color: range === r ? colors.primaryForeground : colors.mutedForeground,
                      fontFamily: range === r ? "Inter_600SemiBold" : "Inter_400Regular",
                    },
                  ]}
                >
                  {r === 0 ? "All" : `${r}d`}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        <BPChart readings={filteredReadings} title="Blood Pressure" />

        {averages && (
          <>
            <Text
              style={[
                styles.sectionTitle,
                { color: colors.foreground, fontFamily: "Inter_600SemiBold", paddingHorizontal: 16 },
              ]}
            >
              Averages
            </Text>
            <View style={styles.statsRow}>
              <StatCard
                label="AVG SYSTOLIC"
                value={averages.systolic}
                unit="mmHg"
                accentColor={colors.chartSystolic}
              />
              <StatCard
                label="AVG DIASTOLIC"
                value={averages.diastolic}
                unit="mmHg"
                accentColor={colors.chartDiastolic}
              />
              <StatCard
                label="AVG BPM"
                value={averages.bpm}
                unit="bpm"
                accentColor={colors.chartBPM}
              />
            </View>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    paddingHorizontal: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
  },
  greeting: {
    fontSize: 12,
    letterSpacing: 0.5,
    marginBottom: 2,
  },
  headerTitle: {
    fontSize: 26,
  },
  addBtn: {
    width: 42,
    height: 42,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    paddingTop: 16,
  },
  latestSection: {
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 15,
    marginBottom: 10,
    paddingHorizontal: 16,
  },
  rangeSection: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    marginBottom: 10,
    marginTop: 8,
  },
  rangeSelector: {
    flexDirection: "row",
    padding: 3,
    gap: 2,
  },
  rangeBtn: {
    paddingHorizontal: 14,
    paddingVertical: 6,
  },
  rangeBtnText: {
    fontSize: 13,
  },
  statsRow: {
    flexDirection: "row",
    gap: 10,
    paddingHorizontal: 16,
    marginBottom: 16,
    marginTop: 8,
  },
  emptyHero: {
    marginHorizontal: 16,
    padding: 32,
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 18,
    marginTop: 4,
  },
  emptySubtitle: {
    fontSize: 14,
    textAlign: "center",
    lineHeight: 20,
  },
  logBtn: {
    marginTop: 8,
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  logBtnText: {
    fontSize: 15,
  },
});
