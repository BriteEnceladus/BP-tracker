import React, { createContext, useCallback, useContext, useEffect, useState } from "react";
import { BPReading } from "@/utils/bpUtils";
import { storage, setActiveKey } from "@/utils/bpStorage";
import { useCrypto } from "@/context/CryptoContext";

interface BPContextType {
  readings: BPReading[];
  isLoading: boolean;
  addReading: (reading: Omit<BPReading, "id">) => Promise<void>;
  importReadings: (readings: Omit<BPReading, "id">[]) => Promise<number>;
  updateReading: (id: string, reading: Omit<BPReading, "id">) => Promise<void>;
  deleteReading: (id: string) => Promise<void>;
  clearAll: () => Promise<void>;
}

const BPContext = createContext<BPContextType | null>(null);

export function BPProvider({ children }: { children: React.ReactNode }) {
  const [readings, setReadings] = useState<BPReading[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { cryptoKey, isUnlocked } = useCrypto();

  useEffect(() => {
    setActiveKey(cryptoKey);

    if (!isUnlocked) {
      setReadings([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    storage
      .getAll()
      .then((all) => setReadings(all))
      .catch((e) => console.error("Failed to load readings", e))
      .finally(() => setIsLoading(false));
  }, [cryptoKey, isUnlocked]);

  const addReading = useCallback(async (reading: Omit<BPReading, "id">) => {
    const newReading = await storage.add(reading);
    setReadings((prev) =>
      [newReading, ...prev].sort(
        (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      )
    );
  }, []);

  const importReadings = useCallback(
    async (newReadings: Omit<BPReading, "id">[]): Promise<number> => {
      const imported: BPReading[] = [];
      for (const r of newReadings) {
        const reading = await storage.add(r);
        imported.push(reading);
      }
      setReadings((prev) =>
        [...prev, ...imported].sort(
          (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        )
      );
      return imported.length;
    },
    []
  );

  const updateReading = useCallback(async (id: string, reading: Omit<BPReading, "id">) => {
    await storage.update(id, reading);
    setReadings((prev) => prev.map((r) => (r.id === id ? { ...reading, id } : r)));
  }, []);

  const deleteReading = useCallback(async (id: string) => {
    await storage.remove(id);
    setReadings((prev) => prev.filter((r) => r.id !== id));
  }, []);

  const clearAll = useCallback(async () => {
    await storage.clear();
    setReadings([]);
  }, []);

  return (
    <BPContext.Provider
      value={{ readings, isLoading, addReading, importReadings, updateReading, deleteReading, clearAll }}
    >
      {children}
    </BPContext.Provider>
  );
}

export function useBP(): BPContextType {
  const ctx = useContext(BPContext);
  if (!ctx) throw new Error("useBP must be used within BPProvider");
  return ctx;
}
