import React, { createContext, useContext } from "react";

export interface CryptoContextType {
  isSetup: boolean;
  isUnlocked: boolean;
  cryptoKey: unknown;
  isLoading: boolean;
  biometricSupported: boolean;
  biometricEnrolled: boolean;
  setupPassword: (password: string) => Promise<void>;
  unlock: (password: string) => Promise<boolean>;
  unlockWithBiometric: () => Promise<boolean>;
  lock: () => void;
  changePassword: (oldPassword: string, newPassword: string) => Promise<void>;
  enrollBiometric: () => Promise<void>;
  removeBiometric: () => Promise<void>;
}

const CryptoContext = createContext<CryptoContextType>({
  isSetup: true,
  isUnlocked: true,
  cryptoKey: null,
  isLoading: false,
  biometricSupported: false,
  biometricEnrolled: false,
  setupPassword: async () => {},
  unlock: async () => true,
  unlockWithBiometric: async () => false,
  lock: () => {},
  changePassword: async () => {},
  enrollBiometric: async () => {},
  removeBiometric: async () => {},
});

export function CryptoProvider({ children }: { children: React.ReactNode }) {
  return (
    <CryptoContext.Provider
      value={{
        isSetup: true,
        isUnlocked: true,
        cryptoKey: null,
        isLoading: false,
        biometricSupported: false,
        biometricEnrolled: false,
        setupPassword: async () => {},
        unlock: async () => true,
        unlockWithBiometric: async () => false,
        lock: () => {},
        changePassword: async () => {},
        enrollBiometric: async () => {},
        removeBiometric: async () => {},
      }}
    >
      {children}
    </CryptoContext.Provider>
  );
}

export function useCrypto(): CryptoContextType {
  return useContext(CryptoContext);
}
