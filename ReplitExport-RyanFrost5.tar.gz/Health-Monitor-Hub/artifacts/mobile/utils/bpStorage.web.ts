import Dexie, { type EntityTable } from "dexie";
import { BPReading, generateId } from "./bpUtils";
import type { StorageAdapter } from "./bpStorage";
import {
  deriveKey,
  encryptData,
  decryptData,
  createVerifier,
  verifyKey,
  generateSalt,
} from "./crypto.web";

interface EncryptedRecord {
  id: string;
  payload: string;
  iv: string;
}

interface MetaRecord {
  key: string;
  value: string;
}

interface BioKeyRecord {
  purpose: string;
  key: CryptoKey;
}

class BPDatabase extends Dexie {
  readings!: EntityTable<EncryptedRecord, "id">;
  meta!: EntityTable<MetaRecord, "key">;
  bioKeys!: EntityTable<BioKeyRecord, "purpose">;

  constructor() {
    super("BPTrackerDB");

    this.version(1).stores({
      readings: "id, timestamp, systolic, diastolic, bpm",
    });

    this.version(2)
      .stores({ readings: "id", meta: "key" })
      .upgrade(async (tx) => {
        const oldReadings = await tx.table("readings").toArray();
        await tx.table("readings").clear();
        for (const r of oldReadings) {
          await tx.table("readings").add({
            id: r.id as string,
            payload: JSON.stringify(r),
            iv: "",
          });
        }
      });

    this.version(3).stores({
      readings: "id",
      meta: "key",
      bioKeys: "purpose",
    });
  }
}

const db = new BPDatabase();

let _activeKey: CryptoKey | null = null;

export function setActiveKey(key: unknown): void {
  _activeKey = key as CryptoKey | null;
}

function bufToB64(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function b64ToBuf(b64: string): ArrayBuffer {
  const binary = atob(b64);
  const buf = new ArrayBuffer(binary.length);
  const bytes = new Uint8Array(buf);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return buf;
}

async function decodeRecord(record: EncryptedRecord): Promise<BPReading> {
  if (!record.iv) return JSON.parse(record.payload) as BPReading;
  if (!_activeKey) throw new Error("No decryption key available");
  const text = await decryptData(_activeKey, { iv: record.iv, payload: record.payload });
  return JSON.parse(text) as BPReading;
}

async function encodeRecord(reading: BPReading): Promise<EncryptedRecord> {
  if (!_activeKey) return { id: reading.id, payload: JSON.stringify(reading), iv: "" };
  const { iv, payload } = await encryptData(_activeKey, JSON.stringify(reading));
  return { id: reading.id, payload, iv };
}

export async function isEncryptionSetup(): Promise<boolean> {
  const salt = await db.meta.get("salt");
  return !!salt;
}

export async function setupEncryption(password: string): Promise<CryptoKey> {
  const salt = generateSalt();
  const key = await deriveKey(password, salt);
  const verifier = await createVerifier(key);

  const existing = await db.readings.toArray();
  const tempKey = _activeKey;
  _activeKey = key;
  for (const record of existing) {
    if (!record.iv) {
      const reading = JSON.parse(record.payload) as BPReading;
      const encrypted = await encodeRecord(reading);
      await db.readings.put(encrypted);
    }
  }
  _activeKey = tempKey;

  await db.meta.bulkPut([
    { key: "salt", value: salt },
    { key: "verifier_iv", value: verifier.iv },
    { key: "verifier_payload", value: verifier.payload },
  ]);

  return key;
}

export async function unlockWithPassword(password: string): Promise<CryptoKey | null> {
  const [saltMeta, verifierIv, verifierPayload] = await Promise.all([
    db.meta.get("salt"),
    db.meta.get("verifier_iv"),
    db.meta.get("verifier_payload"),
  ]);

  if (!saltMeta || !verifierIv || !verifierPayload) return null;

  const key = await deriveKey(password, saltMeta.value);
  const isValid = await verifyKey(key, { iv: verifierIv.value, payload: verifierPayload.value });
  return isValid ? key : null;
}

export async function changeEncryptionPassword(
  oldKey: unknown,
  newPassword: string
): Promise<CryptoKey> {
  const castOldKey = oldKey as CryptoKey;
  const newSalt = generateSalt();
  const newKey = await deriveKey(newPassword, newSalt);
  const verifier = await createVerifier(newKey);

  const existing = await db.readings.toArray();
  for (const record of existing) {
    let reading: BPReading;
    if (record.iv) {
      const text = await decryptData(castOldKey, { iv: record.iv, payload: record.payload });
      reading = JSON.parse(text) as BPReading;
    } else {
      reading = JSON.parse(record.payload) as BPReading;
    }
    const { iv, payload } = await encryptData(newKey, JSON.stringify(reading));
    await db.readings.put({ id: record.id, payload, iv });
  }

  await db.meta.bulkPut([
    { key: "salt", value: newSalt },
    { key: "verifier_iv", value: verifier.iv },
    { key: "verifier_payload", value: verifier.payload },
  ]);

  return newKey;
}

export async function isBiometricSupported(): Promise<boolean> {
  if (typeof window === "undefined" || !window.PublicKeyCredential) return false;
  try {
    return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
  } catch {
    return false;
  }
}

export async function isBiometricEnrolled(): Promise<boolean> {
  const cred = await db.meta.get("bio_cred_id");
  return !!cred;
}

export async function enrollBiometric(masterPassword: string): Promise<void> {
  const challenge = crypto.getRandomValues(new Uint8Array(32));
  const userId = crypto.getRandomValues(new Uint8Array(16));
  const hostname = window.location.hostname;

  const credential = (await navigator.credentials.create({
    publicKey: {
      challenge,
      rp: { name: "BP Tracker", id: hostname },
      user: { id: userId, name: "bp-user", displayName: "BP Tracker User" },
      pubKeyCredParams: [
        { type: "public-key", alg: -7 },
        { type: "public-key", alg: -257 },
      ],
      authenticatorSelection: {
        authenticatorAttachment: "platform",
        userVerification: "required",
        residentKey: "preferred",
      },
      timeout: 60000,
    },
  })) as PublicKeyCredential | null;

  if (!credential) throw new Error("Biometric enrollment cancelled");

  const wrapperKey = await crypto.subtle.generateKey(
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );

  const { iv, payload } = await encryptData(wrapperKey, masterPassword);

  await db.bioKeys.put({ purpose: "wrapper", key: wrapperKey });
  await db.meta.bulkPut([
    { key: "bio_cred_id", value: bufToB64(credential.rawId) },
    { key: "bio_enc_payload", value: payload },
    { key: "bio_enc_iv", value: iv },
  ]);
}

export async function authenticateWithBiometric(): Promise<string | null> {
  const credIdMeta = await db.meta.get("bio_cred_id");
  if (!credIdMeta) return null;

  const challenge = crypto.getRandomValues(new Uint8Array(32));
  const hostname = window.location.hostname;

  const assertion = (await navigator.credentials.get({
    publicKey: {
      challenge,
      rpId: hostname,
      allowCredentials: [
        {
          type: "public-key",
          id: b64ToBuf(credIdMeta.value),
          transports: ["internal"],
        },
      ],
      userVerification: "required",
      timeout: 60000,
    },
  })) as PublicKeyCredential | null;

  if (!assertion) return null;

  const bioKey = await db.bioKeys.get("wrapper");
  if (!bioKey) return null;

  const [encPayload, encIv] = await Promise.all([
    db.meta.get("bio_enc_payload"),
    db.meta.get("bio_enc_iv"),
  ]);
  if (!encPayload || !encIv) return null;

  try {
    const password = await decryptData(bioKey.key, {
      iv: encIv.value,
      payload: encPayload.value,
    });
    return password;
  } catch {
    return null;
  }
}

export async function updateBiometricPassword(newPassword: string): Promise<void> {
  const bioKey = await db.bioKeys.get("wrapper");
  if (!bioKey) return;
  const { iv, payload } = await encryptData(bioKey.key, newPassword);
  await db.meta.bulkPut([
    { key: "bio_enc_payload", value: payload },
    { key: "bio_enc_iv", value: iv },
  ]);
}

export async function removeBiometric(): Promise<void> {
  await db.bioKeys.delete("wrapper");
  await Promise.all([
    db.meta.delete("bio_cred_id"),
    db.meta.delete("bio_enc_payload"),
    db.meta.delete("bio_enc_iv"),
  ]);
}

class EncryptedDexieAdapter implements StorageAdapter {
  async getAll(): Promise<BPReading[]> {
    const records = await db.readings.toArray();
    const readings = await Promise.all(records.map(decodeRecord));
    return readings.sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  async add(reading: Omit<BPReading, "id">): Promise<BPReading> {
    const newReading: BPReading = { ...reading, id: generateId() };
    await db.readings.add(await encodeRecord(newReading));
    return newReading;
  }

  async update(id: string, reading: Omit<BPReading, "id">): Promise<void> {
    await db.readings.put(await encodeRecord({ ...reading, id }));
  }

  async remove(id: string): Promise<void> {
    await db.readings.delete(id);
  }

  async clear(): Promise<void> {
    await Promise.all([db.readings.clear(), db.meta.clear(), db.bioKeys.clear()]);
  }
}

export const storage: StorageAdapter = new EncryptedDexieAdapter();
