export interface EncryptedData {
  iv: string;
  payload: string;
}

export interface PasswordStrength {
  score: 0 | 1 | 2 | 3 | 4;
  label: string;
  color: string;
  feedback: string;
}

function bufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function base64ToBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const buf = new ArrayBuffer(binary.length);
  const bytes = new Uint8Array(buf);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return buf;
}

export function generateSalt(): string {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  return bufferToBase64(salt.buffer as ArrayBuffer);
}

export async function deriveKey(password: string, saltBase64: string): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    "PBKDF2",
    false,
    ["deriveKey"]
  );
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: base64ToBuffer(saltBase64),
      iterations: 100_000,
      hash: "SHA-256",
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

export async function encryptData(key: CryptoKey, plaintext: string): Promise<EncryptedData> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const enc = new TextEncoder();
  const ciphertext = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    enc.encode(plaintext)
  );
  return {
    iv: bufferToBase64(iv.buffer as ArrayBuffer),
    payload: bufferToBase64(ciphertext),
  };
}

export async function decryptData(key: CryptoKey, data: EncryptedData): Promise<string> {
  const plaintext = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: base64ToBuffer(data.iv) },
    key,
    base64ToBuffer(data.payload)
  );
  return new TextDecoder().decode(plaintext);
}

const VERIFIER_TEXT = "BP_TRACKER_V1_OK";

export async function createVerifier(key: CryptoKey): Promise<EncryptedData> {
  return encryptData(key, VERIFIER_TEXT);
}

export async function verifyKey(key: CryptoKey, verifier: EncryptedData): Promise<boolean> {
  try {
    const result = await decryptData(key, verifier);
    return result === VERIFIER_TEXT;
  } catch {
    return false;
  }
}

export function getPasswordStrength(password: string): PasswordStrength {
  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;
  score = Math.min(4, score);

  const levels = [
    { label: "Weak", color: "#EF4444", feedback: "Too short — use at least 8 characters" },
    { label: "Fair", color: "#F97316", feedback: "Add uppercase letters or a number" },
    { label: "Good", color: "#EAB308", feedback: "Add symbols to make it stronger" },
    { label: "Strong", color: "#22C55E", feedback: "Great password!" },
    { label: "Very Strong", color: "#16A34A", feedback: "Excellent — very secure!" },
  ];

  return { score: score as 0 | 1 | 2 | 3 | 4, ...levels[score] };
}
