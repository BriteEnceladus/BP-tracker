import AsyncStorage from "@react-native-async-storage/async-storage";
import { BPReading, generateId } from "./bpUtils";

export interface StorageAdapter {
  getAll(): Promise<BPReading[]>;
  add(reading: Omit<BPReading, "id">): Promise<BPReading>;
  update(id: string, reading: Omit<BPReading, "id">) : Promise<void>;
  remove(id: string): Promise<void>;
  clear(): Promise<void>;
}

const STORAGE_KEY = "@bp_readings";

class AsyncStorageAdapter implements StorageAdapter {
  async getAll(): Promise<BPReading[]> {
    const data = await AsyncStorage.getItem(STORAGE_KEY);
    return data ? (JSON.parse(data) as BPReading[]) : [];
  }

  async add(reading: Omit<BPReading, "id">): Promise<BPReading> {
    const all = await this.getAll();
    const newReading: BPReading = { ...reading, id: generateId() };
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify([...all, newReading]));
    return newReading;
  }

  async update(id: string, reading: Omit<BPReading, "id">): Promise<void> {
    const all = await this.getAll();
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(all.map((r) => (r.id === id ? { ...reading, id } : r))));
  }

  async remove(id: string): Promise<void> {
    const all = await this.getAll();
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(all.filter((r) => r.id !== id)));
  }

  async clear(): Promise<void> {
    await AsyncStorage.removeItem(STORAGE_KEY);
  }
}

export const storage: StorageAdapter = new AsyncStorageAdapter();

export function setActiveKey(_key: unknown): void {}
export async function isEncryptionSetup(): Promise<boolean> { return false; }
export async function setupEncryption(_password: string): Promise<unknown> { return null; }
export async function unlockWithPassword(_password: string): Promise<unknown> { return null; }
export async function changeEncryptionPassword(_oldKey: unknown, _newPassword: string): Promise<unknown> { return null; }
export async function isBiometricSupported(): Promise<boolean> { return false; }
export async function isBiometricEnrolled(): Promise<boolean> { return false; }
export async function enrollBiometric(_masterPassword: string): Promise<void> {}
export async function authenticateWithBiometric(): Promise<string | null> { return null; }
export async function updateBiometricPassword(_newPassword: string): Promise<void> {}
export async function removeBiometric(): Promise<void> {}
