import { BPReading } from "./bpUtils";

export interface ParsedRow {
  rowIndex: number;
  reading: Omit<BPReading, "id"> | null;
  displayDate: string;
  displayBP: string;
  displayBPM: string;
  errors: string[];
  isValid: boolean;
}

export interface ImportPreview {
  rows: ParsedRow[];
  validCount: number;
  invalidCount: number;
  totalParsed: number;
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === "," && !inQuotes) {
      result.push(current.trim());
      current = "";
    } else {
      current += ch;
    }
  }
  result.push(current.trim());
  return result;
}

function normalizeKey(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]/g, "");
}

const COLUMN_ALIASES: Record<string, string[]> = {
  date: ["date", "readingdate", "recorddate", "measuredat", "datum", "fecha"],
  time: ["time", "readingtime", "recordtime", "hora", "zeit"],
  datetime: ["datetime", "datetime", "timestamp", "datetime"],
  systolic: ["systolic", "sys", "sbp", "systolicmmhg", "systolicpressure", "upper"],
  diastolic: ["diastolic", "dia", "dbp", "diastolicmmhg", "diastolicpressure", "lower"],
  bpm: ["bpm", "hr", "pulse", "heartrate", "heartbeat", "pulserate"],
  notes: ["notes", "note", "comment", "comments", "memo", "remark", "remarks", "observation"],
};

function mapColumns(headers: string[]): Record<string, number> {
  const map: Record<string, number> = {};
  for (const [field, aliases] of Object.entries(COLUMN_ALIASES)) {
    const idx = headers.findIndex((h) => aliases.includes(normalizeKey(h)));
    if (idx !== -1) map[field] = idx;
  }
  return map;
}

function parseTime(timeStr: string): { h: number; m: number } | null {
  const s = timeStr.trim();
  const m12 = s.match(/^(\d{1,2}):(\d{2})(?::\d{2})?\s*(am|pm)$/i);
  if (m12) {
    let h = parseInt(m12[1], 10);
    const min = parseInt(m12[2], 10);
    const mer = m12[3].toLowerCase();
    if (mer === "pm" && h !== 12) h += 12;
    if (mer === "am" && h === 12) h = 0;
    if (h >= 0 && h <= 23 && min >= 0 && min <= 59) return { h, m: min };
  }
  const m24 = s.match(/^(\d{1,2}):(\d{2})/);
  if (m24) {
    const h = parseInt(m24[1], 10);
    const min = parseInt(m24[2], 10);
    if (h >= 0 && h <= 23 && min >= 0 && min <= 59) return { h, m: min };
  }
  return null;
}

function parseFlexibleDate(dateStr: string, timeStr?: string): Date | null {
  const d = dateStr.trim();

  let parsed: Date | null = null;

  // ISO datetime: 2025-01-15T08:30 or 2025-01-15 08:30
  if (/^\d{4}-\d{1,2}-\d{1,2}[T ]\d{1,2}:\d{2}/.test(d)) {
    const dt = new Date(d.replace(" ", "T"));
    if (!isNaN(dt.getTime())) return dt;
  }

  // ISO date: 2025-01-15
  if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(d)) {
    const [y, mo, day] = d.split("-").map(Number);
    parsed = new Date(y, mo - 1, day);
  }
  // US: MM/DD/YYYY or M/D/YYYY
  else if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(d)) {
    const [mo, day, y] = d.split("/").map(Number);
    parsed = new Date(y, mo - 1, day);
  }
  // European dot: DD.MM.YYYY
  else if (/^\d{1,2}\.\d{1,2}\.\d{4}$/.test(d)) {
    const [day, mo, y] = d.split(".").map(Number);
    parsed = new Date(y, mo - 1, day);
  }
  // Fallback to native parsing
  else {
    const native = new Date(d);
    if (!isNaN(native.getTime())) parsed = native;
  }

  if (!parsed || isNaN(parsed.getTime())) return null;

  if (timeStr) {
    const t = parseTime(timeStr);
    if (t) parsed.setHours(t.h, t.m, 0, 0);
    else parsed.setHours(0, 0, 0, 0);
  } else {
    parsed.setHours(0, 0, 0, 0);
  }

  return parsed;
}

function parseRow(
  values: string[],
  colMap: Record<string, number>,
  rowIndex: number
): ParsedRow {
  const get = (field: string): string => {
    const idx = colMap[field];
    return idx !== undefined ? (values[idx] ?? "").trim() : "";
  };

  const errors: string[] = [];

  // ── Date/time ──
  let timestamp: string | null = null;
  const dateStr = get("datetime") || get("date");
  const timeStr = get("datetime") ? "" : get("time");

  if (!dateStr) {
    errors.push("Missing date");
  } else {
    const dt = parseFlexibleDate(dateStr, timeStr || undefined);
    if (!dt) {
      errors.push("Could not parse date");
    } else {
      timestamp = dt.toISOString();
    }
  }

  // ── Systolic ──
  let systolic: number | null = null;
  const sysStr = get("systolic");
  if (!sysStr) {
    errors.push("Missing systolic");
  } else {
    const v = parseInt(sysStr, 10);
    if (isNaN(v)) errors.push("Invalid systolic value");
    else if (v < 60 || v > 250) errors.push(`Systolic ${v} out of range (60–250)`);
    else systolic = v;
  }

  // ── Diastolic ──
  let diastolic: number | null = null;
  const diaStr = get("diastolic");
  if (!diaStr) {
    errors.push("Missing diastolic");
  } else {
    const v = parseInt(diaStr, 10);
    if (isNaN(v)) errors.push("Invalid diastolic value");
    else if (v < 30 || v > 150) errors.push(`Diastolic ${v} out of range (30–150)`);
    else diastolic = v;
  }

  // ── BPM ──
  let bpm: number | null = null;
  const bpmStr = get("bpm");
  if (!bpmStr) {
    errors.push("Missing BPM");
  } else {
    const v = parseInt(bpmStr, 10);
    if (isNaN(v)) errors.push("Invalid BPM value");
    else if (v < 30 || v > 250) errors.push(`BPM ${v} out of range (30–250)`);
    else bpm = v;
  }

  const notes = get("notes");

  const isValid = errors.length === 0;
  const reading: Omit<BPReading, "id"> | null =
    isValid && timestamp && systolic !== null && diastolic !== null && bpm !== null
      ? { timestamp, systolic, diastolic, bpm, notes: notes || undefined }
      : null;

  const displayDate = timestamp
    ? new Date(timestamp).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }) +
      " " +
      new Date(timestamp).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })
    : "—";

  const displayBP =
    systolic !== null && diastolic !== null ? `${systolic}/${diastolic}` : "—/—";
  const displayBPM = bpm !== null ? String(bpm) : "—";

  return { rowIndex, reading, displayDate, displayBP, displayBPM, errors, isValid };
}

export const MAX_PREVIEW_ROWS = 200;

export function previewCSV(text: string): ImportPreview {
  const lines = text
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .split("\n")
    .filter((l) => l.trim());

  if (lines.length < 2) {
    return { rows: [], validCount: 0, invalidCount: 0, totalParsed: 0 };
  }

  const headers = parseCSVLine(lines[0]);
  const colMap = mapColumns(headers);

  // Check required columns are mapped
  const hasSystolic = "systolic" in colMap;
  const hasDiastolic = "diastolic" in colMap;
  const hasBPM = "bpm" in colMap;
  const hasDate = "date" in colMap || "datetime" in colMap;

  if (!hasSystolic || !hasDiastolic || !hasBPM || !hasDate) {
    return { rows: [], validCount: 0, invalidCount: 0, totalParsed: 0 };
  }

  const dataLines = lines.slice(1);
  const rows: ParsedRow[] = [];
  let validCount = 0;
  let invalidCount = 0;

  for (let i = 0; i < dataLines.length; i++) {
    const values = parseCSVLine(dataLines[i]);
    if (values.every((v) => !v)) continue; // skip blank lines
    const row = parseRow(values, colMap, i + 2); // rowIndex is 1-based line number
    rows.push(row);
    if (row.isValid) validCount++;
    else invalidCount++;
  }

  return { rows, validCount, invalidCount, totalParsed: rows.length };
}

export function detectMissingColumns(text: string): string[] {
  const firstLine = text.split(/\r?\n/)[0] ?? "";
  const headers = parseCSVLine(firstLine);
  const colMap = mapColumns(headers);
  const missing: string[] = [];
  if (!("date" in colMap) && !("datetime" in colMap)) missing.push("date");
  if (!("systolic" in colMap)) missing.push("systolic");
  if (!("diastolic" in colMap)) missing.push("diastolic");
  if (!("bpm" in colMap)) missing.push("bpm");
  return missing;
}
