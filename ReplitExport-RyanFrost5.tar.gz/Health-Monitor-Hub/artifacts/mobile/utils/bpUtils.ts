export type BPCategory = "normal" | "elevated" | "stage1" | "stage2" | "crisis";

export interface BPReading {
  id: string;
  timestamp: string;
  systolic: number;
  diastolic: number;
  bpm: number;
  notes?: string;
}

export function getBPCategory(systolic: number, diastolic: number): BPCategory {
  if (systolic > 180 || diastolic > 120) return "crisis";
  if (systolic >= 140 || diastolic >= 90) return "stage2";
  if (systolic >= 130 || diastolic >= 80) return "stage1";
  if (systolic >= 120 && diastolic < 80) return "elevated";
  return "normal";
}

export function getCategoryLabel(category: BPCategory): string {
  const labels: Record<BPCategory, string> = {
    normal: "Normal",
    elevated: "Elevated",
    stage1: "High BP Stage 1",
    stage2: "High BP Stage 2",
    crisis: "Hypertensive Crisis",
  };
  return labels[category];
}

export function getCategoryColorKey(
  category: BPCategory
): "normal" | "elevated" | "stage1" | "stage2" | "crisis" {
  return category;
}

export function formatTimestamp(isoString: string): string {
  const date = new Date(isoString);
  return date.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

export function formatDate(isoString: string): string {
  const date = new Date(isoString);
  return date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function formatTime(isoString: string): string {
  const date = new Date(isoString);
  return date.toLocaleTimeString(undefined, {
    hour: "numeric",
    minute: "2-digit",
  });
}

export function generateId(): string {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}

function toISODateStr(isoString: string): string {
  const d = new Date(isoString);
  const y = d.getFullYear();
  const mo = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${mo}-${day}`;
}

function toISOTimeStr(isoString: string): string {
  const d = new Date(isoString);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

export function readingsToCSV(readings: BPReading[]): string {
  const header = "date,time,systolic,diastolic,bpm,notes";
  const rows = readings
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .map((r) => {
      const notes = r.notes ? `"${r.notes.replace(/"/g, '""')}"` : "";
      return `${toISODateStr(r.timestamp)},${toISOTimeStr(r.timestamp)},${r.systolic},${r.diastolic},${r.bpm},${notes}`;
    });
  return [header, ...rows].join("\n");
}

export function getAverages(readings: BPReading[]) {
  if (readings.length === 0) return null;
  const total = readings.reduce(
    (acc, r) => ({
      systolic: acc.systolic + r.systolic,
      diastolic: acc.diastolic + r.diastolic,
      bpm: acc.bpm + r.bpm,
    }),
    { systolic: 0, diastolic: 0, bpm: 0 }
  );
  return {
    systolic: Math.round(total.systolic / readings.length),
    diastolic: Math.round(total.diastolic / readings.length),
    bpm: Math.round(total.bpm / readings.length),
  };
}

export function getReadingsForDays(readings: BPReading[], days: number): BPReading[] {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);
  return readings.filter((r) => new Date(r.timestamp) >= cutoff);
}
