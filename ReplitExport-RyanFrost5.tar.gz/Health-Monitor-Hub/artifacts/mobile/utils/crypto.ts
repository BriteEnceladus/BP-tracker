export interface EncryptedData {
  iv: string;
  payload: string;
}

export interface PasswordStrength {
  score: 0 | 1 | 2 | 3 | 4;
  label: string;
  color: string;
  feedback: string;
}

export function getPasswordStrength(password: string): PasswordStrength {
  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;
  score = Math.min(4, score);

  const levels = [
    { label: "Weak", color: "#EF4444", feedback: "Too short — use at least 8 characters" },
    { label: "Fair", color: "#F97316", feedback: "Add uppercase letters or a number" },
    { label: "Good", color: "#EAB308", feedback: "Add symbols to make it stronger" },
    { label: "Strong", color: "#22C55E", feedback: "Great password!" },
    { label: "Very Strong", color: "#16A34A", feedback: "Excellent — very secure!" },
  ];

  return { score: score as 0 | 1 | 2 | 3 | 4, ...levels[score] };
}
