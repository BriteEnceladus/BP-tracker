import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useCrypto } from "@/context/CryptoContext";
import { getPasswordStrength } from "@/utils/crypto";

type Mode = "setup" | "biometric" | "password";

export function LockScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    isSetup,
    biometricEnrolled,
    biometricSupported,
    setupPassword,
    unlock,
    unlockWithBiometric,
  } = useCrypto();

  const initialMode: Mode = !isSetup ? "setup" : biometricEnrolled ? "biometric" : "password";
  const [mode, setMode] = useState<Mode>(initialMode);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [error, setError] = useState("");
  const [bioError, setBioError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [bioLoading, setBioLoading] = useState(false);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const didAutoTrigger = useRef(false);

  useEffect(() => {
    if (mode !== "biometric" || didAutoTrigger.current) return;
    didAutoTrigger.current = true;
    const t = setTimeout(() => triggerBiometric(), 600);
    return () => clearTimeout(t);
  }, [mode]);

  useEffect(() => {
    if (mode !== "biometric") return;
    const anim = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.08, duration: 1000, useNativeDriver: false }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: false }),
      ])
    );
    anim.start();
    return () => anim.stop();
  }, [mode, pulseAnim]);

  const triggerBiometric = async () => {
    setBioLoading(true);
    setBioError("");
    try {
      const success = await unlockWithBiometric();
      if (!success) {
        setBioError("Authentication failed. Try again or use your password.");
      }
    } catch {
      setBioError("Biometrics unavailable. Use your password.");
    } finally {
      setBioLoading(false);
    }
  };

  const strength = mode === "setup" ? getPasswordStrength(password) : null;
  const passwordsMatch = confirm === password;
  const canSubmit = (() => {
    if (isLoading || !password) return false;
    if (mode === "setup") return (strength?.score ?? 0) >= 1 && passwordsMatch && confirm.length > 0;
    return true;
  })();

  const handleSubmit = async () => {
    if (!canSubmit) return;
    setIsLoading(true);
    setError("");
    try {
      if (mode === "setup") {
        if (!passwordsMatch) { setError("Passwords do not match."); return; }
        await setupPassword(password);
      } else {
        const ok = await unlock(password);
        if (!ok) { setError("Incorrect password. Please try again."); setPassword(""); }
      }
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  if (mode === "biometric") {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View
          style={[
            styles.biometricContent,
            { paddingTop: insets.top + 48, paddingBottom: insets.bottom + 32 },
          ]}
        >
          <View style={[styles.iconWrap, { backgroundColor: colors.primary + "22" }]}>
            <Feather name="shield" size={32} color={colors.primary} />
          </View>
          <Text style={[styles.appName, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>
            BP Tracker
          </Text>
          <Text style={[styles.title, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>
            Welcome back
          </Text>

          <TouchableOpacity
            onPress={triggerBiometric}
            disabled={bioLoading}
            activeOpacity={0.8}
            style={styles.biometricBtnWrap}
          >
            <Animated.View
              style={[
                styles.biometricRing,
                {
                  borderColor: bioLoading ? colors.mutedForeground : colors.primary,
                  transform: [{ scale: pulseAnim }],
                },
              ]}
            >
              <View
                style={[
                  styles.biometricInner,
                  { backgroundColor: bioLoading ? colors.muted : colors.primary + "22" },
                ]}
              >
                {bioLoading ? (
                  <ActivityIndicator size="large" color={colors.primary} />
                ) : (
                  <Feather name="smartphone" size={48} color={colors.primary} />
                )}
              </View>
            </Animated.View>
          </TouchableOpacity>

          <Text style={[styles.bioLabel, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
            {bioLoading ? "Waiting for biometric…" : "Tap to unlock with biometrics"}
          </Text>
          <Text style={[styles.bioSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            Use your fingerprint or Face ID to access your data
          </Text>

          {bioError ? (
            <View style={[styles.errorWrap, { backgroundColor: colors.destructive + "18" }]}>
              <Feather name="alert-circle" size={14} color={colors.destructive} />
              <Text style={[styles.errorText, { color: colors.destructive, fontFamily: "Inter_400Regular" }]}>
                {bioError}
              </Text>
            </View>
          ) : null}

          <TouchableOpacity
            style={[styles.usePasswordBtn, { borderColor: colors.border }]}
            onPress={() => { setMode("password"); setBioError(""); }}
            activeOpacity={0.7}
          >
            <Feather name="lock" size={14} color={colors.mutedForeground} />
            <Text style={[styles.usePasswordText, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>
              Use Password Instead
            </Text>
          </TouchableOpacity>

          <View style={[styles.encryptedBadge, { backgroundColor: colors.normal + "18", borderRadius: 20 }]}>
            <Feather name="shield" size={12} color={colors.normal} />
            <Text style={[styles.encryptedText, { color: colors.normal, fontFamily: "Inter_500Medium" }]}>
              AES-256-GCM · PBKDF2 · 100,000 iterations
            </Text>
          </View>
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          { paddingTop: insets.top + 48, paddingBottom: insets.bottom + 32 },
        ]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.iconWrap, { backgroundColor: colors.primary + "22" }]}>
          <Feather name="shield" size={36} color={colors.primary} />
        </View>

        <Text style={[styles.appName, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>
          BP Tracker
        </Text>
        <Text style={[styles.title, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>
          {mode === "setup" ? "Secure your health data" : "Welcome back"}
        </Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
          {mode === "setup"
            ? "Create a master password to encrypt all your readings with AES-256. Your data stays private, even if your device is compromised."
            : "Enter your master password to access your blood pressure readings."}
        </Text>

        <View style={styles.form}>
          <View
            style={[
              styles.inputWrap,
              { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
            ]}
          >
            <Feather name="lock" size={18} color={colors.mutedForeground} style={styles.inputIcon} />
            <TextInput
              style={[styles.input, { color: colors.foreground, fontFamily: "Inter_400Regular" }]}
              placeholder={mode === "setup" ? "Create a password" : "Master password"}
              placeholderTextColor={colors.mutedForeground}
              secureTextEntry={!showPassword}
              value={password}
              onChangeText={(t) => { setPassword(t); setError(""); }}
              autoCapitalize="none"
              autoCorrect={false}
              onSubmitEditing={mode === "password" ? handleSubmit : undefined}
              returnKeyType={mode === "password" ? "done" : "next"}
            />
            <TouchableOpacity onPress={() => setShowPassword((v) => !v)} style={styles.eyeBtn}>
              <Feather name={showPassword ? "eye-off" : "eye"} size={18} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>

          {mode === "setup" && password.length > 0 && strength && (
            <View style={styles.strengthWrap}>
              <View style={[styles.strengthBar, { backgroundColor: colors.border }]}>
                {[0, 1, 2, 3, 4].map((i) => (
                  <View
                    key={i}
                    style={[
                      styles.strengthSegment,
                      { backgroundColor: i <= strength.score ? strength.color : "transparent", borderRadius: 3 },
                    ]}
                  />
                ))}
              </View>
              <View style={styles.strengthRow}>
                <Text style={[styles.strengthLabel, { color: strength.color, fontFamily: "Inter_600SemiBold" }]}>
                  {strength.label}
                </Text>
                <Text style={[styles.strengthFeedback, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                  {strength.feedback}
                </Text>
              </View>
            </View>
          )}

          {mode === "setup" && (
            <View
              style={[
                styles.inputWrap,
                {
                  backgroundColor: colors.card,
                  borderColor: confirm.length > 0 && !passwordsMatch ? colors.destructive : colors.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <Feather name="lock" size={18} color={colors.mutedForeground} style={styles.inputIcon} />
              <TextInput
                style={[styles.input, { color: colors.foreground, fontFamily: "Inter_400Regular" }]}
                placeholder="Confirm password"
                placeholderTextColor={colors.mutedForeground}
                secureTextEntry={!showConfirm}
                value={confirm}
                onChangeText={(t) => { setConfirm(t); setError(""); }}
                autoCapitalize="none"
                autoCorrect={false}
                onSubmitEditing={handleSubmit}
                returnKeyType="done"
              />
              <TouchableOpacity onPress={() => setShowConfirm((v) => !v)} style={styles.eyeBtn}>
                <Feather name={showConfirm ? "eye-off" : "eye"} size={18} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>
          )}

          {error ? (
            <View style={[styles.errorWrap, { backgroundColor: colors.destructive + "18" }]}>
              <Feather name="alert-circle" size={14} color={colors.destructive} />
              <Text style={[styles.errorText, { color: colors.destructive, fontFamily: "Inter_400Regular" }]}>
                {error}
              </Text>
            </View>
          ) : null}

          <TouchableOpacity
            style={[
              styles.submitBtn,
              { backgroundColor: canSubmit ? colors.primary : colors.muted, borderRadius: colors.radius },
            ]}
            onPress={handleSubmit}
            disabled={!canSubmit || isLoading}
            activeOpacity={0.8}
          >
            {isLoading ? (
              <ActivityIndicator color={colors.primaryForeground} />
            ) : (
              <Text
                style={[
                  styles.submitText,
                  { color: canSubmit ? colors.primaryForeground : colors.mutedForeground, fontFamily: "Inter_600SemiBold" },
                ]}
              >
                {mode === "setup" ? "Set Password & Continue" : "Unlock"}
              </Text>
            )}
          </TouchableOpacity>

          {biometricEnrolled && biometricSupported && mode === "password" && (
            <TouchableOpacity
              style={[styles.biometricFallbackBtn, { borderColor: colors.border, borderRadius: colors.radius }]}
              onPress={() => { setMode("biometric"); didAutoTrigger.current = false; setError(""); }}
              activeOpacity={0.7}
            >
              <Feather name="smartphone" size={16} color={colors.primary} />
              <Text style={[styles.biometricFallbackText, { color: colors.primary, fontFamily: "Inter_500Medium" }]}>
                Use Biometrics Instead
              </Text>
            </TouchableOpacity>
          )}
        </View>

        {mode === "setup" && (
          <View
            style={[
              styles.warningBox,
              { backgroundColor: colors.elevated + "18", borderColor: colors.elevated + "44", borderRadius: colors.radius },
            ]}
          >
            <Feather name="alert-triangle" size={16} color={colors.elevated} style={{ marginTop: 1 }} />
            <Text style={[styles.warningText, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
              <Text style={{ fontFamily: "Inter_600SemiBold", color: colors.foreground }}>Important: </Text>
              If you forget this password, your data cannot be recovered — encryption is client-side only. Write it down and store it safely.
            </Text>
          </View>
        )}

        {mode === "password" && (
          <Text style={[styles.forgotNote, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            Forgot your password? Data is encrypted client-side and cannot be recovered without the password.
          </Text>
        )}

        <View style={[styles.encryptedBadge, { backgroundColor: colors.normal + "18", borderRadius: 20 }]}>
          <Feather name="shield" size={12} color={colors.normal} />
          <Text style={[styles.encryptedText, { color: colors.normal, fontFamily: "Inter_500Medium" }]}>
            AES-256-GCM · PBKDF2 · 100,000 iterations
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flexGrow: 1, alignItems: "center", paddingHorizontal: 24 },
  biometricContent: {
    flex: 1,
    alignItems: "center",
    paddingHorizontal: 24,
    justifyContent: "center",
  },
  iconWrap: {
    width: 72,
    height: 72,
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 16,
  },
  appName: { fontSize: 16, letterSpacing: 0.5, marginBottom: 12 },
  title: { fontSize: 26, textAlign: "center", marginBottom: 12 },
  subtitle: { fontSize: 14, textAlign: "center", lineHeight: 22, maxWidth: 340, marginBottom: 32 },
  form: { width: "100%", maxWidth: 400, gap: 12 },
  inputWrap: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    paddingHorizontal: 14,
    height: 52,
  },
  inputIcon: { marginRight: 10 },
  input: { flex: 1, fontSize: 15, height: "100%" },
  eyeBtn: { padding: 4 },
  strengthWrap: { gap: 6 },
  strengthBar: { flexDirection: "row", height: 4, borderRadius: 2, gap: 3, overflow: "hidden" },
  strengthSegment: { flex: 1, height: "100%" },
  strengthRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  strengthLabel: { fontSize: 12 },
  strengthFeedback: { fontSize: 12 },
  errorWrap: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
  },
  errorText: { fontSize: 13, flex: 1 },
  submitBtn: { height: 52, justifyContent: "center", alignItems: "center", marginTop: 4 },
  submitText: { fontSize: 16 },
  biometricFallbackBtn: {
    height: 48,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderWidth: 1,
  },
  biometricFallbackText: { fontSize: 15 },
  warningBox: {
    flexDirection: "row",
    gap: 10,
    padding: 14,
    marginTop: 24,
    maxWidth: 400,
    width: "100%",
    borderWidth: 1,
  },
  warningText: { fontSize: 13, lineHeight: 20, flex: 1 },
  forgotNote: { fontSize: 12, textAlign: "center", marginTop: 20, maxWidth: 320, lineHeight: 18 },
  encryptedBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginTop: 28,
  },
  encryptedText: { fontSize: 11 },
  biometricBtnWrap: { marginVertical: 32 },
  biometricRing: {
    width: 140,
    height: 140,
    borderRadius: 70,
    borderWidth: 2,
    justifyContent: "center",
    alignItems: "center",
  },
  biometricInner: {
    width: 116,
    height: 116,
    borderRadius: 58,
    justifyContent: "center",
    alignItems: "center",
  },
  bioLabel: { fontSize: 18, textAlign: "center", marginBottom: 8 },
  bioSub: { fontSize: 13, textAlign: "center", marginBottom: 20, maxWidth: 280, lineHeight: 20 },
  usePasswordBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 24,
    borderWidth: 1,
    marginTop: 4,
  },
  usePasswordText: { fontSize: 14 },
});
