import React, { useCallback, useRef, useState } from "react";
import {
  ActivityIndicator,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { useBP } from "@/context/BPContext";
import { previewCSV, detectMissingColumns, ParsedRow, ImportPreview } from "@/utils/csvImport";
import { BPReading } from "@/utils/bpUtils";

type Phase = "idle" | "preview" | "importing" | "done" | "error";

interface State {
  phase: Phase;
  preview?: ImportPreview;
  fileName?: string;
  importedCount?: number;
  errorMsg?: string;
}

const SAMPLE_CSV = `date,time,systolic,diastolic,bpm,notes
2025-01-15,08:30,128,82,68,"Morning reading"
2025-01-14,19:45,135,88,72,"After workout"
2025-01-13,07:00,122,79,65,
2025-01-12,21:30,140,90,80,"Stressed at work"`;

export function CSVImportModal({
  visible,
  onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) {
  const colors = useColors();
  const { importReadings } = useBP();
  const [state, setState] = useState<State>({ phase: "idle" });
  const [showSample, setShowSample] = useState(false);

  const handleClose = useCallback(() => {
    setState({ phase: "idle" });
    setShowSample(false);
    onClose();
  }, [onClose]);

  const processFile = useCallback(
    (text: string, fileName: string) => {
      try {
        const missing = detectMissingColumns(text);
        if (missing.length > 0) {
          setState({
            phase: "error",
            errorMsg: `Missing required columns: ${missing.join(", ")}.\n\nExpected columns: date, systolic, diastolic, bpm`,
          });
          return;
        }
        const preview = previewCSV(text);
        if (preview.totalParsed === 0) {
          setState({ phase: "error", errorMsg: "No data rows found in the file." });
          return;
        }
        setState({ phase: "preview", preview, fileName });
      } catch {
        setState({ phase: "error", errorMsg: "Could not parse the file. Make sure it is a valid CSV." });
      }
    },
    []
  );

  const triggerFilePicker = useCallback(() => {
    if (Platform.OS !== "web") return;
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".csv,text/csv,application/csv";
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      try {
        const text = await file.text();
        processFile(text, file.name);
      } catch {
        setState({ phase: "error", errorMsg: "Failed to read the file." });
      }
    };
    input.click();
  }, [processFile]);

  const handleImport = useCallback(async () => {
    if (!state.preview) return;
    const validReadings = state.preview.rows
      .filter((r) => r.isValid && r.reading)
      .map((r) => r.reading as Omit<BPReading, "id">);

    setState({ phase: "importing" });
    try {
      const count = await importReadings(validReadings);
      setState({ phase: "done", importedCount: count });
    } catch {
      setState({ phase: "error", errorMsg: "Failed to import readings. Please try again." });
    }
  }, [state.preview, importReadings]);

  const r = colors.radius;
  const PREVIEW_LIMIT = 100;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={handleClose}>
      <View style={styles.overlay}>
        <View
          style={[
            styles.sheet,
            { backgroundColor: colors.card, borderRadius: r * 1.5, borderColor: colors.border },
          ]}
        >
          {/* Header */}
          <View style={styles.sheetHeader}>
            <Text style={[styles.sheetTitle, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>
              {state.phase === "done" ? "Import Complete" : "Import from CSV"}
            </Text>
            <TouchableOpacity onPress={handleClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <Feather name="x" size={22} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>

          {/* ── IDLE ── */}
          {state.phase === "idle" && (
            <ScrollView showsVerticalScrollIndicator={false} style={styles.body}>
              {Platform.OS !== "web" ? (
                <View style={styles.notSupported}>
                  <Feather name="monitor" size={40} color={colors.mutedForeground} />
                  <Text style={[styles.notSupportedTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
                    Web / PWA only
                  </Text>
                  <Text style={[styles.notSupportedSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                    CSV import requires the web version. Open BP Tracker in your browser or install it as a PWA to import data.
                  </Text>
                </View>
              ) : (
                <>
                  <Text style={[styles.idleDesc, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                    Upload a CSV file with your historical readings. Your data is encrypted on import.
                  </Text>

                  <View style={[styles.formatBox, { backgroundColor: colors.muted, borderRadius: r }]}>
                    <View style={styles.formatRow}>
                      <Feather name="columns" size={14} color={colors.primary} />
                      <Text style={[styles.formatTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
                        Expected columns
                      </Text>
                    </View>
                    {[
                      ["date", "2025-01-15, 01/15/2025, etc."],
                      ["time", "08:30 or 8:30 AM (optional)"],
                      ["systolic", "60–250 mmHg"],
                      ["diastolic", "30–150 mmHg"],
                      ["bpm", "30–250"],
                      ["notes", "Optional text"],
                    ].map(([col, hint]) => (
                      <View key={col} style={styles.colRow}>
                        <Text style={[styles.colName, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>
                          {col}
                        </Text>
                        <Text style={[styles.colHint, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                          {hint}
                        </Text>
                      </View>
                    ))}
                  </View>

                  <TouchableOpacity
                    style={styles.sampleToggle}
                    onPress={() => setShowSample((v) => !v)}
                    activeOpacity={0.7}
                  >
                    <Feather
                      name={showSample ? "chevron-up" : "chevron-down"}
                      size={14}
                      color={colors.primary}
                    />
                    <Text style={[styles.sampleToggleText, { color: colors.primary, fontFamily: "Inter_500Medium" }]}>
                      {showSample ? "Hide sample CSV" : "Show sample CSV"}
                    </Text>
                  </TouchableOpacity>

                  {showSample && (
                    <View style={[styles.sampleBox, { backgroundColor: colors.background, borderColor: colors.border, borderRadius: r }]}>
                      <Text style={[styles.sampleText, { color: colors.foreground, fontFamily: "Inter_400Regular" }]}>
                        {SAMPLE_CSV}
                      </Text>
                    </View>
                  )}

                  <TouchableOpacity
                    style={[styles.pickBtn, { backgroundColor: colors.primary, borderRadius: r }]}
                    onPress={triggerFilePicker}
                    activeOpacity={0.8}
                  >
                    <Feather name="upload" size={18} color={colors.primaryForeground} />
                    <Text style={[styles.pickBtnText, { color: colors.primaryForeground, fontFamily: "Inter_600SemiBold" }]}>
                      Select CSV File
                    </Text>
                  </TouchableOpacity>
                </>
              )}
            </ScrollView>
          )}

          {/* ── PREVIEW ── */}
          {state.phase === "preview" && state.preview && (
            <>
              {/* Summary bar */}
              <View style={[styles.summaryBar, { backgroundColor: colors.muted }]}>
                <View style={styles.summaryItem}>
                  <Feather name="check-circle" size={14} color={colors.normal} />
                  <Text style={[styles.summaryText, { color: colors.normal, fontFamily: "Inter_600SemiBold" }]}>
                    {state.preview.validCount} valid
                  </Text>
                </View>
                {state.preview.invalidCount > 0 && (
                  <View style={styles.summaryItem}>
                    <Feather name="alert-circle" size={14} color={colors.destructive} />
                    <Text style={[styles.summaryText, { color: colors.destructive, fontFamily: "Inter_600SemiBold" }]}>
                      {state.preview.invalidCount} with errors
                    </Text>
                  </View>
                )}
                <Text style={[styles.summaryFile, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                  {state.fileName}
                </Text>
              </View>

              <ScrollView style={styles.previewScroll} showsVerticalScrollIndicator={false}>
                {state.preview.rows.slice(0, PREVIEW_LIMIT).map((row) => (
                  <PreviewRow key={row.rowIndex} row={row} colors={colors} />
                ))}
                {state.preview.rows.length > PREVIEW_LIMIT && (
                  <Text style={[styles.moreRows, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                    … and {state.preview.rows.length - PREVIEW_LIMIT} more rows
                  </Text>
                )}
              </ScrollView>

              <View style={styles.previewActions}>
                <TouchableOpacity
                  style={[styles.cancelBtn, { borderColor: colors.border, borderRadius: r }]}
                  onPress={() => setState({ phase: "idle" })}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.cancelBtnText, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>
                    Back
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.importBtn,
                    {
                      backgroundColor:
                        state.preview.validCount > 0 ? colors.primary : colors.muted,
                      borderRadius: r,
                      flex: 1,
                    },
                  ]}
                  onPress={handleImport}
                  disabled={state.preview.validCount === 0}
                  activeOpacity={0.8}
                >
                  <Feather
                    name="download"
                    size={16}
                    color={
                      state.preview.validCount > 0
                        ? colors.primaryForeground
                        : colors.mutedForeground
                    }
                  />
                  <Text
                    style={[
                      styles.importBtnText,
                      {
                        color:
                          state.preview.validCount > 0
                            ? colors.primaryForeground
                            : colors.mutedForeground,
                        fontFamily: "Inter_600SemiBold",
                      },
                    ]}
                  >
                    Import {state.preview.validCount} Reading
                    {state.preview.validCount !== 1 ? "s" : ""}
                  </Text>
                </TouchableOpacity>
              </View>
            </>
          )}

          {/* ── IMPORTING ── */}
          {state.phase === "importing" && (
            <View style={styles.centeredBody}>
              <ActivityIndicator size="large" color={colors.primary} />
              <Text style={[styles.centeredTitle, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
                Importing & encrypting…
              </Text>
              <Text style={[styles.centeredSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                Each reading is encrypted before saving
              </Text>
            </View>
          )}

          {/* ── DONE ── */}
          {state.phase === "done" && (
            <View style={styles.centeredBody}>
              <View style={[styles.doneIcon, { backgroundColor: colors.normal + "22" }]}>
                <Feather name="check-circle" size={44} color={colors.normal} />
              </View>
              <Text style={[styles.centeredTitle, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>
                {state.importedCount} reading{state.importedCount !== 1 ? "s" : ""} imported
              </Text>
              <Text style={[styles.centeredSub, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                Your dashboard and charts now reflect the imported data.
              </Text>
              <TouchableOpacity
                style={[styles.doneBtn, { backgroundColor: colors.primary, borderRadius: r }]}
                onPress={handleClose}
                activeOpacity={0.8}
              >
                <Text style={[styles.doneBtnText, { color: colors.primaryForeground, fontFamily: "Inter_600SemiBold" }]}>
                  Done
                </Text>
              </TouchableOpacity>
            </View>
          )}

          {/* ── ERROR ── */}
          {state.phase === "error" && (
            <View style={styles.centeredBody}>
              <View style={[styles.doneIcon, { backgroundColor: colors.destructive + "18" }]}>
                <Feather name="alert-circle" size={44} color={colors.destructive} />
              </View>
              <Text style={[styles.centeredTitle, { color: colors.foreground, fontFamily: "Inter_700Bold" }]}>
                Import failed
              </Text>
              <Text style={[styles.errorDetail, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
                {state.errorMsg}
              </Text>
              <TouchableOpacity
                style={[styles.doneBtn, { backgroundColor: colors.primary, borderRadius: r }]}
                onPress={() => setState({ phase: "idle" })}
                activeOpacity={0.8}
              >
                <Text style={[styles.doneBtnText, { color: colors.primaryForeground, fontFamily: "Inter_600SemiBold" }]}>
                  Try Again
                </Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </View>
    </Modal>
  );
}

function PreviewRow({
  row,
  colors,
}: {
  row: ParsedRow;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}) {
  const bg = row.isValid ? "transparent" : colors.destructive + "08";
  const borderColor = row.isValid ? colors.border : colors.destructive + "40";

  return (
    <View
      style={[
        styles.previewRowCard,
        { backgroundColor: bg, borderColor, borderRadius: colors.radius - 2 },
      ]}
    >
      <View style={styles.previewRowLeft}>
        <Text style={[styles.previewDate, { color: row.isValid ? colors.foreground : colors.destructive, fontFamily: "Inter_500Medium" }]}>
          {row.displayDate}
        </Text>
        {row.isValid ? (
          <Text style={[styles.previewValues, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            {row.displayBP} mmHg · {row.displayBPM} bpm
            {row.reading?.notes ? ` · ${row.reading.notes}` : ""}
          </Text>
        ) : (
          <Text style={[styles.previewError, { color: colors.destructive, fontFamily: "Inter_400Regular" }]}>
            {row.errors.join("; ")}
          </Text>
        )}
      </View>
      <Feather
        name={row.isValid ? "check-circle" : "alert-circle"}
        size={16}
        color={row.isValid ? colors.normal : colors.destructive}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.55)",
    justifyContent: "flex-end",
    padding: 12,
    paddingBottom: 28,
  },
  sheet: {
    maxHeight: "90%",
    borderWidth: 1,
    overflow: "hidden",
  },
  sheetHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 18,
  },
  sheetTitle: { fontSize: 20 },
  body: { paddingHorizontal: 20, paddingBottom: 20 },

  // Idle
  idleDesc: { fontSize: 14, lineHeight: 22, marginBottom: 16 },
  formatBox: { padding: 14, gap: 8, marginBottom: 14 },
  formatRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 4 },
  formatTitle: { fontSize: 13 },
  colRow: { flexDirection: "row", gap: 8, paddingLeft: 2 },
  colName: { fontSize: 12, width: 80 },
  colHint: { fontSize: 12, flex: 1 },
  sampleToggle: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 10 },
  sampleToggleText: { fontSize: 13 },
  sampleBox: { padding: 12, borderWidth: 1, marginBottom: 16 },
  sampleText: { fontSize: 11, lineHeight: 18, fontFamily: "monospace" as never },
  pickBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingVertical: 14,
    marginBottom: 8,
  },
  pickBtnText: { fontSize: 16 },

  // Not supported
  notSupported: { alignItems: "center", paddingVertical: 32, gap: 12, paddingHorizontal: 20 },
  notSupportedTitle: { fontSize: 18, textAlign: "center" },
  notSupportedSub: { fontSize: 14, textAlign: "center", lineHeight: 22 },

  // Preview
  summaryBar: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
    gap: 12,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  summaryItem: { flexDirection: "row", alignItems: "center", gap: 6 },
  summaryText: { fontSize: 13 },
  summaryFile: { fontSize: 11, flex: 1 },
  previewScroll: { maxHeight: 340, paddingHorizontal: 12 },
  previewRowCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginVertical: 3,
    borderWidth: 1,
  },
  previewRowLeft: { flex: 1, gap: 2 },
  previewDate: { fontSize: 13 },
  previewValues: { fontSize: 12 },
  previewError: { fontSize: 12 },
  moreRows: { textAlign: "center", fontSize: 12, paddingVertical: 8 },
  previewActions: {
    flexDirection: "row",
    gap: 10,
    padding: 16,
    paddingTop: 12,
  },
  cancelBtn: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  cancelBtnText: { fontSize: 15 },
  importBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  importBtnText: { fontSize: 15 },

  // Centered states (importing / done / error)
  centeredBody: { alignItems: "center", paddingVertical: 32, paddingHorizontal: 24, gap: 14 },
  doneIcon: {
    width: 84,
    height: 84,
    borderRadius: 42,
    justifyContent: "center",
    alignItems: "center",
  },
  centeredTitle: { fontSize: 20, textAlign: "center" },
  centeredSub: { fontSize: 14, textAlign: "center", lineHeight: 22 },
  errorDetail: { fontSize: 13, textAlign: "center", lineHeight: 20 },
  doneBtn: { paddingHorizontal: 32, paddingVertical: 13, marginTop: 4 },
  doneBtnText: { fontSize: 16 },
});
