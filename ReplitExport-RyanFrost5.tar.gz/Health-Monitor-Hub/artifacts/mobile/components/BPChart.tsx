import React, { useMemo } from "react";
import { Dimensions, StyleSheet, Text, View } from "react-native";
import Svg, { Circle, Line, Path, Text as SvgText } from "react-native-svg";
import { useColors } from "@/hooks/useColors";
import { BPReading } from "@/utils/bpUtils";

interface ChartDataset {
  values: number[];
  color: string;
  label: string;
}

interface BPChartProps {
  readings: BPReading[];
  title?: string;
  showBPM?: boolean;
}

const SCREEN_WIDTH = Dimensions.get("window").width;
const CHART_HEIGHT = 160;
const PADDING_LEFT = 40;
const PADDING_RIGHT = 16;
const PADDING_TOP = 16;
const PADDING_BOTTOM = 28;

function buildPath(points: { x: number; y: number }[]): string {
  if (points.length === 0) return "";
  if (points.length === 1) return `M ${points[0].x} ${points[0].y}`;
  let d = `M ${points[0].x} ${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    const cp1x = (points[i].x + points[i - 1].x) / 2;
    const cp1y = points[i - 1].y;
    const cp2x = cp1x;
    const cp2y = points[i].y;
    d += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${points[i].x} ${points[i].y}`;
  }
  return d;
}

export function BPChart({ readings, title, showBPM = false }: BPChartProps) {
  const colors = useColors();
  const chartWidth = SCREEN_WIDTH - 32;
  const innerWidth = chartWidth - PADDING_LEFT - PADDING_RIGHT;
  const innerHeight = CHART_HEIGHT - PADDING_TOP - PADDING_BOTTOM;

  const { datasets, labels, yMin, yMax } = useMemo(() => {
    if (readings.length === 0) {
      return { datasets: [], labels: [], yMin: 60, yMax: 160 };
    }

    const sorted = [...readings].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    const sysValues = sorted.map((r) => r.systolic);
    const diaValues = sorted.map((r) => r.diastolic);
    const bpmValues = sorted.map((r) => r.bpm);

    const allValues = showBPM
      ? [...sysValues, ...diaValues, ...bpmValues]
      : [...sysValues, ...diaValues];

    const rawMin = Math.min(...allValues);
    const rawMax = Math.max(...allValues);
    const padding = Math.max(10, (rawMax - rawMin) * 0.15);
    const yMin = Math.max(0, Math.floor((rawMin - padding) / 10) * 10);
    const yMax = Math.ceil((rawMax + padding) / 10) * 10;

    const labelDates = sorted.map((r) => {
      const d = new Date(r.timestamp);
      return `${d.getMonth() + 1}/${d.getDate()}`;
    });

    const ds: ChartDataset[] = [
      { values: sysValues, color: colors.chartSystolic, label: "SYS" },
      { values: diaValues, color: colors.chartDiastolic, label: "DIA" },
    ];

    if (showBPM) {
      ds.push({ values: bpmValues, color: colors.chartBPM, label: "BPM" });
    }

    return { datasets: ds, labels: labelDates, yMin, yMax };
  }, [readings, showBPM, colors]);

  if (readings.length === 0) {
    return (
      <View
        style={[
          styles.emptyContainer,
          { backgroundColor: colors.card, borderRadius: colors.radius },
        ]}
      >
        <Text style={[styles.emptyText, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
          No data yet. Log your first reading.
        </Text>
      </View>
    );
  }

  const yRange = yMax - yMin;
  const n = readings.length;

  const toY = (val: number) =>
    PADDING_TOP + innerHeight - ((val - yMin) / yRange) * innerHeight;

  const toX = (i: number) =>
    PADDING_LEFT + (n === 1 ? innerWidth / 2 : (i / (n - 1)) * innerWidth);

  const yTicks = 4;
  const yTickValues = Array.from({ length: yTicks + 1 }, (_, i) =>
    Math.round(yMin + (yRange * i) / yTicks)
  );

  const maxLabels = Math.min(n, 5);
  const labelIndices = Array.from({ length: maxLabels }, (_, i) =>
    Math.round((i / (maxLabels - 1 || 1)) * (n - 1))
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.card, borderRadius: colors.radius }]}>
      {title && (
        <Text style={[styles.title, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
          {title}
        </Text>
      )}

      <View style={styles.legend}>
        {datasets.map((ds) => (
          <View key={ds.label} style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: ds.color }]} />
            <Text style={[styles.legendLabel, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>
              {ds.label}
            </Text>
          </View>
        ))}
      </View>

      <Svg width={chartWidth} height={CHART_HEIGHT}>
        {yTickValues.map((val) => {
          const y = toY(val);
          return (
            <React.Fragment key={val}>
              <Line
                x1={PADDING_LEFT}
                y1={y}
                x2={chartWidth - PADDING_RIGHT}
                y2={y}
                stroke={colors.border}
                strokeWidth={1}
                strokeDasharray="4,4"
              />
              <SvgText
                x={PADDING_LEFT - 6}
                y={y + 4}
                textAnchor="end"
                fontSize={9}
                fill={colors.mutedForeground}
                fontFamily="Inter_400Regular"
              >
                {val}
              </SvgText>
            </React.Fragment>
          );
        })}

        {labelIndices.map((idx) => (
          <SvgText
            key={idx}
            x={toX(idx)}
            y={CHART_HEIGHT - 6}
            textAnchor="middle"
            fontSize={9}
            fill={colors.mutedForeground}
            fontFamily="Inter_400Regular"
          >
            {labels[idx]}
          </SvgText>
        ))}

        {datasets.map((ds) => {
          const points = ds.values.map((val, i) => ({ x: toX(i), y: toY(val) }));
          return (
            <React.Fragment key={ds.label}>
              <Path
                d={buildPath(points)}
                stroke={ds.color}
                strokeWidth={2.5}
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {points.map((pt, i) => (
                <Circle
                  key={i}
                  cx={pt.x}
                  cy={pt.y}
                  r={3}
                  fill={ds.color}
                  stroke={colors.card}
                  strokeWidth={1.5}
                />
              ))}
            </React.Fragment>
          );
        })}
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  title: {
    fontSize: 15,
    marginBottom: 8,
    paddingHorizontal: 16,
  },
  legend: {
    flexDirection: "row",
    gap: 16,
    paddingHorizontal: 16,
    marginBottom: 4,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  legendLabel: {
    fontSize: 11,
  },
  emptyContainer: {
    marginHorizontal: 16,
    height: 120,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
  },
  emptyText: {
    fontSize: 14,
  },
});
