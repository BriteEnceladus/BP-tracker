import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import {
  BPReading,
  getBPCategory,
  getCategoryLabel,
  formatDate,
  formatTime,
} from "@/utils/bpUtils";

const CATEGORY_EMOJI_MAP = {
  normal: "checkmark.circle",
  elevated: "exclamationmark.circle",
  stage1: "exclamationmark.triangle",
  stage2: "xmark.circle",
  crisis: "flame",
};

interface BPCardProps {
  reading: BPReading;
  onDelete?: (id: string) => void;
  compact?: boolean;
}

export function BPCard({ reading, onDelete, compact = false }: BPCardProps) {
  const colors = useColors();
  const category = getBPCategory(reading.systolic, reading.diastolic);

  const categoryColorMap = {
    normal: colors.normal,
    elevated: colors.elevated,
    stage1: colors.stage1,
    stage2: colors.stage2,
    crisis: colors.crisis,
  };
  const categoryColor = categoryColorMap[category];

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderRadius: colors.radius,
          borderLeftWidth: 4,
          borderLeftColor: categoryColor,
          shadowColor: colors.foreground,
        },
      ]}
    >
      <View style={styles.header}>
        <View style={styles.dateBlock}>
          <Text style={[styles.date, { color: colors.foreground, fontFamily: "Inter_600SemiBold" }]}>
            {formatDate(reading.timestamp)}
          </Text>
          <Text style={[styles.time, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            {formatTime(reading.timestamp)}
          </Text>
        </View>
        <View style={styles.headerRight}>
          <View
            style={[
              styles.categoryBadge,
              { backgroundColor: categoryColor + "22", borderRadius: 20 },
            ]}
          >
            <Text style={[styles.categoryText, { color: categoryColor, fontFamily: "Inter_600SemiBold" }]}>
              {getCategoryLabel(category)}
            </Text>
          </View>
          {onDelete && (
            <TouchableOpacity
              onPress={() => onDelete(reading.id)}
              style={styles.deleteBtn}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <Feather name="trash-2" size={16} color={colors.mutedForeground} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      <View style={styles.values}>
        <View style={styles.valueBlock}>
          <Text style={[styles.bigValue, { color: colors.chartSystolic, fontFamily: "Inter_700Bold" }]}>
            {reading.systolic}
          </Text>
          <Text style={[styles.valueLabel, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            SYS
          </Text>
        </View>
        <Text style={[styles.slash, { color: colors.border }]}>/</Text>
        <View style={styles.valueBlock}>
          <Text style={[styles.bigValue, { color: colors.chartDiastolic, fontFamily: "Inter_700Bold" }]}>
            {reading.diastolic}
          </Text>
          <Text style={[styles.valueLabel, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            DIA
          </Text>
        </View>
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <View style={styles.valueBlock}>
          <Text style={[styles.bpmValue, { color: colors.chartBPM, fontFamily: "Inter_700Bold" }]}>
            {reading.bpm}
          </Text>
          <Text style={[styles.valueLabel, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            BPM
          </Text>
        </View>
      </View>

      {!compact && reading.notes ? (
        <View style={[styles.notes, { borderTopColor: colors.border }]}>
          <Feather name="message-square" size={12} color={colors.mutedForeground} />
          <Text
            style={[styles.notesText, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}
            numberOfLines={2}
          >
            {reading.notes}
          </Text>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    marginHorizontal: 16,
    marginVertical: 6,
    padding: 16,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 12,
  },
  dateBlock: {
    gap: 2,
  },
  date: {
    fontSize: 14,
  },
  time: {
    fontSize: 12,
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  categoryBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  categoryText: {
    fontSize: 11,
  },
  deleteBtn: {
    padding: 4,
  },
  values: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  valueBlock: {
    alignItems: "center",
    minWidth: 48,
  },
  bigValue: {
    fontSize: 32,
    lineHeight: 36,
  },
  bpmValue: {
    fontSize: 28,
    lineHeight: 32,
  },
  valueLabel: {
    fontSize: 10,
    marginTop: 2,
    letterSpacing: 1,
  },
  slash: {
    fontSize: 28,
    marginHorizontal: 4,
  },
  divider: {
    width: 1,
    height: 40,
    marginHorizontal: 8,
  },
  notes: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 6,
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
  },
  notesText: {
    fontSize: 13,
    flex: 1,
    lineHeight: 18,
  },
});
