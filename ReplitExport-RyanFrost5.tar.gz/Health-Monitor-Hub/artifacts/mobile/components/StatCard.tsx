import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";

interface StatCardProps {
  label: string;
  value: string | number;
  unit?: string;
  accentColor?: string;
  subtitle?: string;
}

export function StatCard({ label, value, unit, accentColor, subtitle }: StatCardProps) {
  const colors = useColors();
  const accent = accentColor ?? colors.primary;

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderRadius: colors.radius,
          shadowColor: colors.foreground,
        },
      ]}
    >
      <View style={[styles.accent, { backgroundColor: accent + "22" }]}>
        <View style={[styles.accentDot, { backgroundColor: accent }]} />
      </View>
      <Text style={[styles.label, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>
        {label}
      </Text>
      <View style={styles.valueRow}>
        <Text style={[styles.value, { color: accent, fontFamily: "Inter_700Bold" }]}>
          {value}
        </Text>
        {unit && (
          <Text style={[styles.unit, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
            {unit}
          </Text>
        )}
      </View>
      {subtitle && (
        <Text style={[styles.subtitle, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]}>
          {subtitle}
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    padding: 14,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
    minWidth: 90,
  },
  accent: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 8,
  },
  accentDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  label: {
    fontSize: 11,
    letterSpacing: 0.5,
    marginBottom: 4,
  },
  valueRow: {
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 3,
  },
  value: {
    fontSize: 26,
    lineHeight: 28,
  },
  unit: {
    fontSize: 11,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 10,
    marginTop: 4,
  },
});
