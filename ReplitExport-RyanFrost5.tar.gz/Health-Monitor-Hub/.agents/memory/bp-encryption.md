---
name: BP Tracker Encryption Architecture
description: How client-side AES-256-GCM encryption is wired into the Expo/Metro app — platform files, key lifecycle, Dexie schema migration.
---

## The Rule
Encryption is web-only. Native uses OS sandbox (AsyncStorage). Web uses Web Crypto API (AES-256-GCM + PBKDF2). The session CryptoKey lives in React state only — never persisted.

**Why:** `CryptoKey` and `crypto.subtle` don't exist in React Native's JS environment. Forcing a shared implementation would require shims that add complexity with no benefit since native OS provides equivalent protection via the app sandbox/Keychain.

## How to Apply
- Platform-specific Metro resolution: `.web.ts` for web, `.ts` for native.
  - `utils/crypto.web.ts` — full Web Crypto API (deriveKey, encryptData, decryptData, verifyKey, createVerifier, generateSalt)
  - `utils/crypto.ts` — native stub, only `getPasswordStrength` (pure JS, no web APIs)
  - `utils/bpStorage.web.ts` — Dexie v2, per-record AES-GCM encryption, `setActiveKey()` module setter
  - `utils/bpStorage.ts` — AsyncStorage, stub versions of all crypto exports
  - `context/CryptoContext.web.tsx` — real PBKDF2/unlock/setup/changePassword
  - `context/CryptoContext.tsx` — native stub, always `isSetup=true, isUnlocked=true, cryptoKey=null`
- `BPContext` calls `setActiveKey(cryptoKey)` in a `useEffect` on `[cryptoKey, isUnlocked]` before calling `storage.getAll()`.
- `_layout.tsx` wraps with `CryptoProvider` → `AppGate` (shows `LockScreen` when `!isUnlocked || !isSetup`).

## Dexie Schema
- v1 (old): `readings: "id, timestamp, systolic, diastolic, bpm"` — plaintext BPReading objects
- v2 (current): `readings: "id"` + `meta: "key"` — encrypted blobs `{id, payload, iv}`
- Migration v1→v2: old records wrapped as `{id, payload: JSON.stringify(r), iv: ''}` (empty iv = unencrypted legacy)
- `setupEncryption()` re-encrypts any record with `iv === ''` using the new key

## Key Derivation
- Algorithm: PBKDF2, SHA-256, 100,000 iterations, 256-bit AES-GCM key
- Salt: 16 random bytes, base64-stored in `meta` table under key `"salt"`
- Verifier: AES-GCM encrypted known string `"BP_TRACKER_V1_OK"` stored as `verifier_iv` + `verifier_payload` in meta
- Password verification: derive key → try decrypt verifier → check plaintext match

## CryptoKey Type Safety
- `CryptoContextType.cryptoKey` is typed as `unknown` (not `CryptoKey`) to avoid native TS errors
- `setActiveKey` in both storage files accepts `unknown` (web casts internally to `CryptoKey | null`)
- `changeEncryptionPassword` accepts `unknown` and casts to `CryptoKey` internally

## Clear All Data
- `storage.clear()` clears both `readings` AND `meta` tables — wipes encryption setup too
- User must set up a new password after clearing data
