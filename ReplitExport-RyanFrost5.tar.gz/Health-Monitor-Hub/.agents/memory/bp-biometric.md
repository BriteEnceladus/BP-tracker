---
name: BP Tracker Biometric Unlock
description: How WebAuthn biometric unlock is wired to the AES-256-GCM encryption system — security model, storage, and key pitfalls.
---

## Security Model (important to understand)
Biometrics = "convenience unlock" model, NOT a cryptographic primitive.
- A non-extractable AES-GCM "wrapper key" is stored in Dexie `bioKeys` table via IndexedDB structured clone.
- On enrollment: wrapper key encrypts the master password → stored in Dexie `meta`. WebAuthn credential ID also stored in meta.
- On biometric unlock: WebAuthn `credentials.get()` verifies presence → app reads wrapper key from Dexie → decrypts password → runs PBKDF2 → gets session CryptoKey.
- The wrapper key is in IndexedDB and technically accessible to any JS on the origin without biometric. WebAuthn acts as a UX gate (user intent proof), not a cryptographic key derivation. This is the same model as banking apps.

**Why:** The WebAuthn PRF extension (which would provide true crypto from biometrics) is not supported on iOS Safari. This approach works on all platforms.

## Dexie v3 Schema
- v3 adds `bioKeys: "purpose"` table alongside `readings: "id"` and `meta: "key"`.
- `BioKeyRecord = { purpose: string, key: CryptoKey }` — IndexedDB can store CryptoKey objects via structured clone algorithm (they survive page reloads even though non-extractable).

## Key Pitfalls
- **Import path:** `bpStorage.web.ts` must import from `"./crypto.web"` explicitly (not `"./crypto"`). TypeScript resolves `"./crypto"` to the native stub, missing all the web exports.
- **Uint8Array typing:** In TypeScript 5.x, `new Uint8Array(length)` is `Uint8Array<ArrayBufferLike>` which is NOT assignable to `BufferSource` (Web Crypto API). Fix: allocate `new ArrayBuffer(n)` then wrap with `new Uint8Array(buf)` and return the `ArrayBuffer`.
- **rpId:** Use `window.location.hostname` for the WebAuthn RP ID. Don't hardcode — it must match the actual origin at enrollment time.
- **Master password in state:** `CryptoContext.web.tsx` stores `masterPassword` string in React state (in-memory only) so `enrollBiometric()` can access it after unlock. This is intentional and documented — clearing it on `lock()`.
- **Password change → re-encrypt stored password:** `changePassword` in CryptoContext calls `updateBiometricPassword(newPassword)` to re-encrypt the stored password with the existing wrapper key if biometric is enrolled.

## Functions Added (bpStorage.web.ts)
`isBiometricSupported`, `isBiometricEnrolled`, `enrollBiometric(password)`, `authenticateWithBiometric()`, `updateBiometricPassword(password)`, `removeBiometric()`. All stubbed in `bpStorage.ts` (native).

## CryptoContext Interface
Both `CryptoContext.tsx` (native) and `CryptoContext.web.tsx` export identical `CryptoContextType` with: `biometricSupported`, `biometricEnrolled`, `enrollBiometric()`, `unlockWithBiometric()`, `removeBiometric()`. Native stubs return `false`/no-op.

## LockScreen Modes
Three modes: `'setup'` (first time), `'biometric'` (enrolled + supported), `'password'` (fallback).
- Biometric mode auto-triggers `unlockWithBiometric()` 600ms after mount (once).
- Pulse animation on the biometric button.
- "Use Password Instead" button switches to password mode.
- "Use Biometrics Instead" button in password mode switches back.

## Preview/iframe Limitation
WebAuthn may fail in Replit's embedded preview iframe due to cross-origin restrictions. The error handler checks for "not allowed"/"cross-origin" and shows a message to open the app directly in a new tab or install as PWA. Works fully in a standalone tab or installed PWA.
